%% 
% cd ../..
% clc
% startQQLM
%% load model and software parameters. add noise to model parameters
m=QQLMLoadModel('MPBase.txt');
ParamBase = QQLMLoadParameters('ParamListCFL.txt');
ParamCurr = ParamBase;
mAll = QQLMAddNoiseToParameters(m,0.05,20,false);
%% now simulate with sum/prod
ParamCurr.Simulation.Simulator = @QQLMSimEngCFL_Sum;
ParamCurr.Simulation.SimEngineSpecific = @CNOhillNonNorm_Prod;
ParamCurr.Filename = 'HomoDimChange1AllSP';
ResHomoDimAllSP = QQLMSimulateFullScenario(mAll,'MPInhibKin.txt',ParamCurr,'MPCritIncHomoDim.txt');
%% plot results from paper
QQLMPlotMedQuartSimEvolution(ResHomoDimAllSP.Model,ResHomoDimAllSP.SimResExpt(end,:,:,:,:));
QQLMPlotMedQuartSimEvolution(ResHomoDimAllSP.Model,ResHomoDimAllSP.SimResExpt(end,1,:,:,:))
plotpassing = squeeze(sum(ResHomoDimAllSP.PassingCombs(end,:,:),3)/size(ResHomoDimAllSP.PassingCombs,3)>0.02);
QQLMPlotMedQuartSimEvolution(ResHomoDimAllSP.Model,ResHomoDimAllSP.SimResExpt(end,plotpassing,:,:,:))
%% compare results to separate criteria
ResHomoDimAllSP.Parameters.Filename = 'HeteroDimChange1AllSP';
ResHeteroDimAllSP = QQLMCompareCritToPrevRes(ResHomoDimAllSP,'MPInhibKin.txt','MPCritIncHeteroDim.txt');
