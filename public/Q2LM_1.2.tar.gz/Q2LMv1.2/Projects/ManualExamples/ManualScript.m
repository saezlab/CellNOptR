%% Copy the following lines while in the Q2LM main directory
%% First we start Q2LM
startQQLM
%Load the model
m = QQLMLoadModel('ManualExModel.txt');
%Load Parameters for CFL
Parameters = QQLMLoadParameters('ParamListCFL.txt');
%make filename more specific
Parameters.Filename = 'ManualCFLEx';
%Now simulate everything with the first scenario containing only
%environments
ResCFL = QQLMSimulateFullScenario(m,'ManualToyScen1.txt',Parameters);
%We could have also run the entire simulation without first loading the 
%model and parameters. 
ResCFL = QQLMSimulateFullScenario('ManualExModel.txt','ManualToyScen1.txt','ParamListCFL.txt');
%
%% We will now plot the simulation results of the CFL result
QQLMPlotAllSimEvolution(ResCFL.Model,ResCFL.SimResExpt)
%each environment plots in a different figure.  If we had had different 
%experiments, they would have been different colors of lines, and different
%models are different line formats.
%
%% Explore ResCFL
%The results structure 'Res' is made up of many fields
ResCFL
%ResCFL.Model stores the model that was simulated (m, in this case).
ResCFL.Model
%ResCFL.SimProjExpt stores the Data Projects that were created when the 
%scenario was imported and simulated during the simulation. There are seven 
%Projects, each with a different environment
ResCFL.SimProjExpt
ResCFL.SimProjExpt(1)
ResCFL.SimProjExpt(2)
ResCFL.SimProjExpt(3)
%In this case, we didn't supply any inhibitors, so none were used and each 
%SimProjExpt just has another Environment
%The values of the stimuli are changing, but their names are the same
ResCFL.SimProjExpt(3).namesStimuli
ResCFL.SimProjExpt(3).valueStimuli
%Thus, the third environment that was stimulatd had two stimuli; A and B, 
%and their values were 1 and 0, respectively.
%
%ResODE.SimResExpt contains the actual simulation results.  Its indices are 
%1: environment, 2: expt condition, 3: Species, 4: time, and 5: model.
%To find the species names, we need to look at the model
ResCFL.Model.specID
% the species are indexed according to the order shown above 
%(i.e. A is 1, B is 2, etc.)
% Thus, the entry Res.SimResExpt(1,1,1,1,1)
ResCFL.SimResExpt(1,1,1,1,1)
% corresponds to the value of the first species (A) in the first 
%environment (A=0,B=0) in the first experiment (there were none so only the 
%environment was simulated), at the first time point in the first model 
%(we only supplied one parameter set).
% The entry Res.SimResExpt(4,1,6,3,1)
ResCFL.SimResExpt(4,1,6,3,1)
% corresponds to the value of the sixth species (F) in the 
%fourth environment (A=0,B=0.5) in the first experiment (there were none, 
%so only the environment was simulated), at the third time point in the 
%first model (we only supplied one parameter set).
%
%% We will now simulate with cFL-based ODEs 
%(note: amodel file must have been loaded at least once previously before 
%it can be simulated with cFL-based ODEs.  This is because the m-file is 
%created the first time it is loaded.  
ResODE = QQLMSimulateFullScenario('ManualExModel.txt','ManualToyScen1.txt','ParamListODE.txt');
QQLMPlotAllSimEvolution(ResODE.Model,ResODE.SimResExpt)
close all
%
%
%% Now we'll simulate the second scenario, which contains inhibition
%experiments.  We'll first simulate with cFL, but before we simulate, we
%will add some noise to the parameters of the models.  This helps prevent 
%the simulation from returning metastable points.  We add 5% noise 20
%times, to result in 20 versions of our original model.
mNoise = QQLMAddNoiseToParameters(m,0.05,20,false);
% notice that m has only one value for all the parameters, while mNoise has
% 20 sets (rows in kMat, nMat, and gMat)
m.nMat
mNoise.nMat
%now simulate and plot
Res2CFL = QQLMSimulateFullScenario(mNoise,'ManualToyScen2.txt','ParamListCFL.txt');
QQLMPlotAllSimEvolution(Res2CFL.Model,Res2CFL.SimResExpt);
% in our plots, we observe oscillations due to the negative feedback from F
% to C.  We will simulate with cFL-based ODEs to see how that affects the
% oscillations.
Res2ODE = QQLMSimulateFullScenario(mNoise,'ManualToyScen2.txt','ParamListODE.txt');
QQLMPlotAllSimEvolution(Res2ODE.Model,Res2ODE.SimResExpt);
% The oscillations are  not present in the ODE simulation.
close all
%% Explore Res2CFL
% We will take a look at the results file resulting from this 
%This time, the scenario did include experiments.  We can see them by
%looking at Res2CFL.SimProjExpt
Res2CFL.SimProjExpt(5)
Res2CFL.SimProjExpt(5).namesStimuli
Res2CFL.SimProjExpt(5).valueStimuli
Res2CFL.SimProjExpt(5).namesInhibitors
Res2CFL.SimProjExpt(5).valueInhibitors
%Thus, the fifth environment that was stimulated had two stimuli; A and B, 
%and their values were 0 and 1, respectively, but this time there were
%inhibitors present for C and D in some of the simulations.
%
%Res2CFL.SimResExpt contains the actual simulation results.  Its indices are 
%1: environment, 2: expt condition, 3: Species, 4: time, and 5: model.
%Again, to find the species names, we need to look at the model
Res2CFL.Model.specID
% Now that we have experiments and multiple models, there are more
% non-singular dimensions. The entry Res.SimResExpt(5,1,6,3,1)
Res2CFL.SimResExpt(5,1,6,5,1)
% corresponds to the value of the sixth species (F) in the 
%fifth environment (A=0,B=1) in the first experiment 
%(no inhibitors present), at the fifth time point in the 
%first model.
%The entry Res.SimResExpt(5,1,6,3,2)
Res2CFL.SimResExpt(5,1,6,5,2)
% corresponds to the previously described value in the second model. 
%The entry Res.SimResExpt(5,6,6,3,20)
Res2CFL.SimResExpt(5,6,6,5,20)
% corresponds to the value of the sixth species (F) in the 
%fifth environment (A=0,B=1) in the sixth experiment 
%(full inhibition of both C and D), at the fifth time point in the 
%twentieth model.
% You can also look at arrays of solutions
squeeze(Res2CFL.SimResExpt(:,:,6,end,1))
% corresponds to the value of the sixth species (F) at the last time point 
%in the first model for all environments (rows) and experiments (cols).
squeeze(Res2CFL.SimResExpt(5,:,6,:,1))
% corresponds to the value of the sixth species (F) in the 
%fifth environment (A=0,B=1) at all time points (cols)
%in the first model for all experiments (rows).
%
%
%
%
%% Querying the model
% We will now query the inhibition of C and D at various levels (Scen3) for
% its affect on decreasing both E and F.  We simply load a "criteria" file
% into Q2LM as well.
Res3CFLCrit = QQLMSimulateFullScenario(mNoise,'ManualToyScen3.txt','ParamListCFL.txt','ManualCrit.txt');
% the resulting Res file has many additional entries
Res3CFLCrit
% Model, SimProjExpt, SimResExpt, and Parameters are as before. ModelComp
% is simply the model that was compared (the same in this case.  It can be
% specified to be different using certain criteria files (see *** for an
% example).  SimResExptEnd is the "end" value of SimResExpt compared to the
% Criteria.  The end is calculated according to the "SteadyStateAvg", which
% is what we put in the criteria file.
% The dimensions are: 1: environment, 2: expt condition, 3: Species, 4: model.
Res3CFLCrit.SimResExptEnd(:,:,5,20)
% is the end value for all environments and experiments
% of the fifth species (E) for the twentieth model
% SimProjCrit is the Project that the Experiments were compared to.  It is
% lacking any alterations in the experimental species.  There are a few
% extra field that Q2LM uses to compare results from simulating this
% project to those of the Scenario file.
Res3CFLCrit.SimProjCrit(5)
Res3CFLCrit.SimProjCrit(5).namesStimuli
Res3CFLCrit.SimProjCrit(5).valueStimuli
Res3CFLCrit.SimProjCrit(5).namesInhibitors
Res3CFLCrit.SimProjCrit(5).valueInhibitors
% SimResComp is similar to SimResExptEnd, except the values are for the
% environment without experimental pertubation.
squeeze(Res3CFLCrit.SimResComp(5,:,:,2))
% is the end comparison value in the fifth environment for all experiments
% and species in the second model.
% 
% CritMat is calculated with the math specified by the Criteria file.  In
% this case, it is the absolute change between the values with and without
% perturbation.  Dimensions are the same as for SimResExptEnd and
% SimResComp
%
% Passing Combs are those experiments that "passed" the criteria.  This is
% determined by comparing CritMat to the amount and sign specified in the
% criteria file.  In our criteria file, we said that both F and E had to
% decrease for the experiment to pass.
%
% Q2LM counts the models that "Passed" for each environment/experiment and
% writes them in a text file saved in the "Results folder"
%
% One can also query a model simulated with ODEs.  This is especially
% useful if oscillations might be confounding the cFL results.
%
Res3ODECrit = QQLMSimulateFullScenario(mNoise,'ManualToyScen3.txt','ParamListODE.txt','ManualCrit.txt');