function startQQLM
% Similar to CellNOpt and DataRail for adding paths.
% 
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%

disp(' ');
disp('               ****************************');
disp(' ');
disp('               Welcome to QQLM for Querying');
disp('                Quantitative Logic Models  ');
disp(' ')
disp('    � Copyright 2011,2012 Massachusetts Institute of Technology')
disp(' ')
disp('           Q2LM is free software: you can redistribute it')
disp('   and/or modify it under the terms of the GNU General Public License') 
disp('   version 2 as published by the Free Software Foundation. Q2LM is') 
disp(' distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;')
disp('  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A') 
disp('       PARTICULAR PURPOSE.  See the GNU General Public License at')
disp(' http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.')
disp(' ');
disp('               ****************************');

dirs2Add = cell(6,1);
dirs2Add{1} = 'QQLMFunctions';
dirs2Add{2} = 'Scenarios';
dirs2Add{3} = 'Models';
dirs2Add{4} = 'Parameters';
dirs2Add{5} = 'Criteria';
dirs2Add{6} = 'Projects';

disp(' ');
disp('            Adding QQLM directories to the path');
filename = mfilename('fullpath');
thisPath = fileparts(filename);

addpath(thisPath,'-end')

% Go backward, so I can delete any missing directories
for i=numel(dirs2Add):-1:1
    dirs2Add{i} = fullfile(thisPath, dirs2Add{i});
    if ~isdir(dirs2Add{i})
        dsip(' ')
        disp(['Unable to locate QQLM directory ' dirs2Add{i}]);
        dirs2Add(i) = [];
    end
end

if isempty(dirs2Add)
    error('Unable to locate any QQLM directories.');
end
for i = 1:numel(dirs2Add)
    if any(regexpi(dirs2Add{i},'Projects'))
        addpath(genpath(dirs2Add{i}),'-end');
    elseif any(regexpi(dirs2Add{i},'QQLMFunctions'))
        addpath(dirs2Add{i},'-end');
        addpath(fullfile(dirs2Add{i},'CNOFunctions'),'-end');
        addpath(fullfile(dirs2Add{i},'PlotFunctions'),'-end');
    else
        addpath(dirs2Add{i},'-end');
    end
end

disp(' ');
disp('                  Paths succesfully loaded');
disp(' ');
