function values = QQLMMakeCondComb(names,valvary,maxnum)
% values = QQLMMakeCondComb(names,valvary,maxnum) makes the combinations 
%   of experiments specified by scenario file columns three through five.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

% initialize
values = zeros(1,numel(names));
count = 2;
numChosen = 1;
while numChosen <= maxnum
    % list of species to take
    SpecCombs = nchoosek(1:numel(names),numChosen);
    % list of values of those species
    ValComb = QQLMfullfact(length(valvary)*ones(1,numChosen));
    for eachSpecComb = 1:size(SpecCombs,1)
        for eachValComb = 1:size(ValComb,1)
            % for each species/value combination, put in values output
            % matrix
            values(count,SpecCombs(eachSpecComb,:)) = valvary(ValComb(eachValComb,:)); 
            count = count + 1;
        end
    end
    numChosen = numChosen+1;
end