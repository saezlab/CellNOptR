function SimResOneTime = QQLMMakeRepTimeVal(SimResExpt,SimProjCrit,Parameters)
% SimResOneTime = QQLMMakeRepTimeVal(SimResExpt,SimProjCrit)
%   Wrapper that calls the correct function (QQLMFindSteadyState or
%   QQLMFindSteadyStateAvg) on SimResExpt based on SimProjCrit.
%   Simulation Parameters are also required as inputs to determine
%   tolerance and numSpecToSS.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

SimResOneTime = nan(size(SimResExpt,1),size(SimResExpt,2),size(SimResExpt,3),size(SimResExpt,5));
if any(regexpi(Parameters.ModelType,'cFL'))
    if size(SimResExpt,4)==1
        % if used only one time point, just reshape
        SimResOneTime = permute(SimResExpt,[1 2 3 5 4]);
    else
        for eachScen = 1:size(SimResExpt,1)
            for eachModel = 1:size(SimResExpt,5)
                % have to do ignore the nans that are filler at the end
                endTimeIx = max(sum(~isnan(squeeze(SimResExpt(eachScen,1,:,:,eachModel))),2));
                currSimRes = permute(SimResExpt(eachScen,:,:,1:endTimeIx,eachModel),[2 3 4 1 5]);
                if ~isempty(currSimRes)
                    if strcmpi(SimProjCrit(1).EndPoint,'SteadyState')
                        SimResOneTime(eachScen,:,:,eachModel) = QQLMFindSteadyState(currSimRes,Parameters.SimEngSpecific);
                    elseif any(regexpi(SimProjCrit(1).EndPoint,'Avg'))
                        SimResOneTime(eachScen,:,:,eachModel) = QQLMFindSteadyStateAvg(currSimRes,Parameters.SimEngSpecific);
                    else
                        error('Undefined Criteria Endpoint')
                    end
                else
                    SimResOneTime(eachScen,:,:,eachModel) = NaN;
                end
            end
        end
    end
elseif any(regexpi(Parameters.ModelType,'ODE'))
    if size(SimResExpt,4)==1
        % if used fsolve to calculate steady state, just reshape
        SimResOneTime = permute(SimResExpt,[1 2 3 5 4]);
    else
        for eachScen = 1:size(SimResExpt,1)
            % have to look through each condition because the ODE simulation
            % didn't necessarily output the same number of time points for
            % each.
            for eachCond = 1:size(SimResExpt,2)
                for eachModel = 1:size(SimResExpt,5)
                    % have to do ignore the nans that are filler at the end
                    endTimeIx = max(sum(~isnan(squeeze(SimResExpt(eachScen,eachCond,:,:,eachModel))),2));
                    currSimRes = permute(SimResExpt(eachScen,eachCond,:,1:endTimeIx,eachModel),[2 3 4 1 5]);
                    if ~isempty(currSimRes)
                        if strcmpi(SimProjCrit(1).EndPoint,'SteadyState')
                            SimResOneTime(eachScen,eachCond,:,eachModel) = QQLMFindSteadyState(currSimRes,Parameters.SimEngSpecific);
                        elseif any(regexpi(SimProjCrit(1).EndPoint,'Avg'))
                            SimResOneTime(eachScen,eachCond,:,eachModel) = QQLMFindSteadyStateAvg(currSimRes,Parameters.SimEngSpecific);
                        else
                            error('Undefined Criteria Endpoint')
                        end
                    else
                        SimResOneTime(eachScen,:,:,eachModel) = NaN;
                    end
                end
            end
        end
    end
else
    error('Undefined model type.  Make sure you input Simulation Parameters')
end