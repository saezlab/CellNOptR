function GuessedCues=QQLMGuessCueNames(Labels)
%   GuessedCues = QQLMGuessCueNames(Labels) returns the characters between
%   commas without any '=' statements in the cellstr input Labels as a 
%   cell of strings output.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

%initialize
GuessedCues=cellstr('');

numCues=size(Labels,1);
%go through each label
for eachLabel=1:numCues
    %see if there's anything there
    if ~isempty(Labels{eachLabel})
        %see if there are any , or =
        commas=findstr(',',Labels{eachLabel});
        equalsSign=findstr('=',Labels{eachLabel});
        %Process name before first comma
        if ~isempty(commas)
            if isempty(equalsSign)
                GuessedCues(end+1)=cellstr(Labels{eachLabel}(1:commas(1)-1));
            elseif equalsSign(1) > commas(1)
                GuessedCues(end+1)=cellstr(Labels{eachLabel}(commas(1)+1:equalsSign(1)-1));
                GuessedCues(end+1)=cellstr(Labels{eachLabel}(1:commas(1)-1));
            elseif equalsSign(1) < commas(1)
                GuessedCues(end+1)=cellstr(Labels{eachLabel}(1:equalsSign(1)-1));
            end
        elseif ~isempty(equalsSign)
            GuessedCues(end+1)=cellstr(Labels{eachLabel}(1:equalsSign(1)-1));
        else
            GuessedCues(end+1)=Labels(eachLabel);
        end
        numInnerCues=length(commas)+1;
        %Process remaining names by looking at the portion after each
        %successive comma, starting with the first comma (indexed as
        %EachName-1.
        for eachName=2:numInnerCues
            equalsSignRemaining=findstr('=',Labels{eachLabel}(commas(eachName-1)+1:end));
            commasRemaining=findstr(',',Labels{eachLabel}(commas(eachName-1)+1:end));
            %If there are more commas
            if ~isempty(commasRemaining)
                %and no equals signs after the remaining comma
                if isempty(equalsSignRemaining)
                    %take portion between comma and next comma
                    GuessedCues(end+1)=cellstr(Labels{eachLabel}(commas(eachName-1)+1:commas(eachName-1)+commasRemaining(1)-1));
                    %if there are equal signs but they are further away
                    %than the next comma
                elseif equalsSignRemaining(1) > commasRemaining(1)
                    %take portion between current and next comma as well as
                    %portion between next comma and equal sign (possibly redundant)
                    GuessedCues(end+1)=cellstr(Labels{eachLabel}(commas(eachName-1)+commasRemaining(1)+1:commas(eachName-1)+equalsSignRemaining(1)-1));
                    GuessedCues(end+1)=cellstr(Labels{eachLabel}(commas(eachName-1)+1:commas(eachName-1)+commasRemaining(1)-1));
                    %if the equals sign is before the next comma
                elseif equalsSignRemaining(1) < commasRemaining(1)
                    %take portion between current comma and equals sign
                    GuessedCues(end+1)=cellstr(Labels{eachLabel}(commas(eachName-1)+1:commas(eachName-1)+equalsSignRemaining(1)-1));
                end
                %if there were no more commas but there were more equal signs
            elseif ~isempty(equalsSignRemaining)
                %take portion between current comma and next equal sign
                GuessedCues(end+1)=cellstr(Labels{eachLabel}(commas(eachName-1)+1:commas(eachName-1)+equalsSignRemaining(1)-1));
                %if there were no more commas or equal signs
            else
                %take portion between current comma and end
                GuessedCues(end+1)=cellstr(Labels{eachLabel}(commas(eachName-1)+1:end));
            end
        end
    end
    clear equalsSign
    clear commas
    clear commasRemaining
    clear equalsSignRemaining
end
%get rid of redundant names
GuessedCues=unique(GuessedCues);
%get rid of '' fake name used for initialization
GuessedCues=GuessedCues(2:end);
%transpose
GuessedCues=GuessedCues';