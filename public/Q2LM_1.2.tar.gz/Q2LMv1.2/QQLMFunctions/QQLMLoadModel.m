function m = QQLMLoadModel(filename)
% m = QQLMLoadModel(filename)
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

if strcmpi(filename(end-3:end),'.mat')
    mLoaded = load(filename);
    if isfield(mLoaded,'m')
        m = mLoaded.m;
        return
    else
        error('Model variable name must be m')
    end
end

fid = fopen(fullfile('Models',filename));
if fid == -1
    fid = fopen(fullfile(filename));
    if fid == -1
        error(['no model ' filename ' found in the "Models" folder or MatLab path'])
    end
end
Desc = textscan(fid,'%s %d %s %s %s %s','CommentStyle','#','delimiter','\t');
fclose(fid);

INs = Desc{1};
Signs = Desc{2};
OUTs = Desc{3};
try
    Gs = cellfun(@eval,Desc{4},'UniformOutput',false);
catch
    error('G parameters were not recognized by MatLab as executable statements.  Edit model text file')
end
try
    Ns = cellfun(@eval,Desc{5},'UniformOutput',false);
catch
    error('N parameters were not recognized by MatLab as executable statements.  Edit model text file')
end
try
    Ks = cellfun(@eval,Desc{6},'UniformOutput',false);
catch
    error('K parameters were not recognized by MatLab as executable statements.  Edit model text file')
end

for i = 1:numel(INs)
    if any(regexpi(INs{i},' '))
        disp(' ')
        disp(['Input ' INs{i} ' has a space that will be removed from the model name'])
        INs{i}(regexpi(INs{i},' ')) = '';
    end
end
for i = 1:numel(OUTs)
    if any(regexpi(OUTs{i},' '))
        disp(' ')
        disp(['Output ' OUTs{i} ' has a space that will be removed from the model name'])
        OUTs{i}(regexpi(OUTs{i},' ')) = '';
    end
end

SpecNames = unique(cat(1,INs,OUTs));
rmSpec = false(numel(SpecNames),1);
for i = 1:numel(SpecNames)
    rmSpec(i) = any(regexpi(SpecNames{i},'and'));
end
AndIDs = SpecNames(rmSpec);
SpecNames(rmSpec)=[];

nands = nnz(rmSpec);

% look for ands make a cell with information about them where the first
% entry contains the rows with their outputs, the second their inputs, and
% eventually we'll put their ID name in the third cell
countINs = zeros(nands,1);
ANDInfo = cell(3,nands);
IsAND = false(numel(INs),1);
for eachRow = 1:numel(INs)
    for eachAND = 1:nands
        if strcmpi(OUTs{eachRow},AndIDs(eachAND))
            ANDInfo{1,eachAND}(end + 1) = eachRow;
            countINs(eachAND,1) = length(ANDInfo{1,eachAND});
            IsAND(eachRow,1) = true;
        elseif strcmpi(INs{eachRow},AndIDs(eachAND))
            ANDInfo{2,eachAND}(end + 1) = eachRow;
            IsAND(eachRow,1) = true;
            % check to make sure these weren't given parameters since they
            % are meaningless.
            if numel(Gs{eachRow}) ~= 1
                disp(' ')
                disp(['Line ' num2str(eachRow) ' detected as the link to an output to an AND gate but multiple parameters found.  They will not be used'])
                Gs{eachRow} = 1;
            end
            if numel(Ns{eachRow}) ~= 1
                disp(' ')
                disp(['Line ' num2str(eachRow) ' detected as the link to an output to an AND gate but multiple parameters found.  They will not be used'])
                Ns{eachRow} = 3;
            end
            if numel(Ks{eachRow}) ~= 1
                disp(' ')
                disp(['Line ' num2str(eachRow) ' detected as the link to an output to an AND gate but multiple parameters found.  They will not be used'])
                Ks{eachRow} = 0.5;
            end
            if Signs(eachRow) == -1
                disp(' ')
                disp(['Line ' num2str(eachRow) ' detected as the link to an output to an AND gate but sign is negative.  This syntax is not recognized and will be ignored.'])
                Signs(eachRow) = 1;
            end
        end
    end
end
numr = numel(INs)-sum(countINs)-nands+nands;

% make ID tags of each gate
IDs = nan(numel(INs,1));
IDs(~IsAND) = 1:(numr-nands);
% the ANDs are at the end
for eachAND = 1:nands
    currID = numr-nands+eachAND;
    IDs(ANDInfo{1,eachAND})=currID;
    IDs(ANDInfo{2,eachAND})=currID;
    ANDInfo{3,eachAND} = currID;
end

uniqIDs = unique(IDs);

% count models
numParams = ones(numel(INs),3);
for countMod = 1:numel(INs)
    numParams(countMod,1) = length(Gs{countMod});
    numParams(countMod,2) = length(Ns{countMod});
    numParams(countMod,3) = length(Ks{countMod});
end
totalNumMod = prod(prod(numParams));

disp(' ')
disp(['Will Create *' num2str(totalNumMod) '* Models'])

% Make combinations of parameters
allParams = QQLMfullfact(numParams(:));
allGs = allParams(:,1:size(allParams,2)/3);
allNs = allParams(:,size(allParams,2)/3+1:2*size(allParams,2)/3);
allKs = allParams(:,2*size(allParams,2)/3+1:3*size(allParams,2)/3);

m.specID = char(SpecNames);
m.maxipg = max([countINs; 1]);
m.numr = numr;
m.nums = numel(SpecNames);
m.timeScale = ones(1,numr);

% initialize necessary fields
ReacNames = cell(numr,1);
m.interMat = zeros(numel(SpecNames),numr);
m.paramMat = zeros(numel(SpecNames),numr);
m.notMat = ones(numel(SpecNames),numr);
m.InputsReacs = zeros(numr,1);
m.finalCube = ones(numr,m.maxipg);
m.gCube=ones(numr, m.maxipg);
m.nCube=ones(numr, m.maxipg);
m.kCube=zeros(numr, m.maxipg);
m.paramCube=nan(numr, m.maxipg);
m.ixNeg=false(numr, m.maxipg);
m.maxIx=zeros(1,numr);

countParams = 1;

for eachID = 1:numr
    CurrRows = find(IDs==uniqIDs(eachID));
    if length(CurrRows)>1 && ~all(IsAND(CurrRows))
        error('something went wrong with AND gate identification')
    elseif length(CurrRows) > 1
        currAND = cat(1,ANDInfo{3,:})==uniqIDs(eachID);
        m.maxIx(eachID) = find(strcmpi(OUTs(CurrRows(CurrRows==ANDInfo{2,currAND})),SpecNames));
        m.interMat(strcmpi(OUTs(CurrRows(CurrRows==ANDInfo{2,currAND})),SpecNames),eachID)=1;
        ReacNames{eachID} = [ReacNames{eachID} '=' SpecNames{m.maxIx(eachID)}];
        CurrRows(CurrRows==ANDInfo{2,currAND})=[];
    else
        m.maxIx(eachID) = find(strcmpi(OUTs(CurrRows(1)),SpecNames));
        ReacNames{eachID} = [ReacNames{eachID} '=' SpecNames{m.maxIx(eachID)}];
        m.interMat(strcmpi(OUTs(CurrRows(1)),SpecNames),eachID)=1;
    end
    for eachIN = 1:length(CurrRows)
        m.interMat(strcmpi(INs(CurrRows(eachIN)),SpecNames),eachID) = -1;
        m.finalCube(eachID,eachIN) = find(strcmpi(INs(CurrRows(eachIN)),SpecNames));
        m.paramMat(strcmpi(INs(CurrRows(eachIN)),SpecNames),eachID) = countParams;
        m.paramCube(eachID,eachIN)=countParams;
        countParams = countParams+1;
        if Signs(CurrRows(eachIN))==-1
            m.notMat(strcmpi(INs(CurrRows(eachIN)),SpecNames),eachID) = 0;
            m.ixNeg(eachID,eachIN) = true;
        end
        if eachIN == 1
            ReacNames{eachID} = [SpecNames{m.finalCube(eachID,eachIN)} ReacNames{eachID}];
        else
            ReacNames{eachID} = [SpecNames{m.finalCube(eachID,eachIN)} '+' ReacNames{eachID}];
        end
    end
    m.InputsReacs(eachID) = length(CurrRows);
end
m.ignoreCube = isnan(m.paramCube);
m.PiXCube = ~isnan(m.paramCube);
m.PiX = m.paramCube(m.PiXCube);
m.reacID = char(ReacNames);
totNumParams = countParams - 1;

% check that all interactions have inputs and outputs
if any(sum(m.interMat==-1,1)<1) || any(sum(m.interMat==1,1)>1)
    disp(' ')
    disp('Model warning: some interactions do not have both input and outputs.',...
        ' Either something was wrong with the txt file or the input and output',...
        ' of an interaction was the same.')
end

%initialize parameter matrices
kMat = zeros(totalNumMod,totNumParams);
nMat = zeros(totalNumMod,totNumParams);
gMat = zeros(totalNumMod,totNumParams);

%make ODE File

fid = fopen(fullfile('Models',[filename(1:end-4) '.m']),'w');
if fid == -1
    disp(' ')
    disp('could not find Models folder.  Will just write M file in current directory')
    fid = fopen([filename(1:end-4) '.m'],'w');
end
Header = ['function dy = ' filename(1:end-4) '(t,y,g,n,k,inh,stim)'];
SecondLine = ['dy = zeros(' num2str(m.nums) ',1);'];
fprintf(fid,'%s \n %s \n',Header,SecondLine);

for eachSpec = 1:m.nums
    localModel = m.interMat(:,m.interMat(eachSpec,:) == 1);
    localNot = m.notMat(:,m.interMat(eachSpec,:) == 1);
    localParams = m.paramMat(:,m.interMat(eachSpec,:) == 1);
    if isempty(localModel)
        ReacString = ['dy(' num2str(eachSpec) ') = - stim(' num2str(eachSpec) ').*inh(' num2str(eachSpec) ').*y(' num2str(eachSpec) ');'];
    else
        ReacString = ['dy(' num2str(eachSpec) ') = stim(' num2str(eachSpec) ').*(inh(' num2str(eachSpec) ').*(max(['];
        for eachReac = 1:size(localModel,2)
            numIns = nnz(localModel(:,eachReac)==-1);
            if numIns>1 && eachReac == 1
                ReacString = [ReacString 'min(['];
            elseif numIns>1 && eachReac > 1
                ReacString = [ReacString ',min(['];
            else
                ReacString = [ReacString ''];
            end
            InputIX = find(localModel(:,eachReac)==-1);
            paramLoc = localParams(localModel(:,eachReac)==-1,eachReac);
            signID = localNot(localModel(:,eachReac)==-1,eachReac)==0;
            for eachIn = 1:numIns
                if signID(eachIn) && eachIn==1 && eachReac ==1
                    ReacString = [ReacString ' 1 - '];
                elseif signID(eachIn) && (eachIn > 1 || eachReac > 1)
                    ReacString = [ReacString ', 1 - '];
                elseif ~signID(eachIn) && (eachIn > 1 || eachReac > 1)
                    ReacString = [ReacString ','];
                end
                ReacString = [ReacString ' g(' num2str(paramLoc(eachIn)) ') .* y(' num2str(InputIX(eachIn)) ').^n(' num2str(paramLoc(eachIn))...
                    ').*(1+k(' num2str(paramLoc(eachIn)) ').^n(' num2str(paramLoc(eachIn)) '))./(y(' num2str(InputIX(eachIn)) ').^n(' num2str(paramLoc(eachIn))...
                    ')+k(' num2str(paramLoc(eachIn)) ').^n(' num2str(paramLoc(eachIn)) '))'];
            end
            if numIns > 1
                ReacString = [ReacString '])'];
            end
        end
        ReacString = [ReacString '])) - y(' num2str(eachSpec) '));'];
    end
    fprintf(fid,'%s\n',ReacString);
end
fclose(fid);
%make Sum Product ODE File

fid = fopen(fullfile('Models',[filename(1:end-4) 'SumProd.m']),'w');
if fid == -1
    disp(' ')
    disp('could not find Models folder.  Will just write M file in current directory')
    fid = fopen([filename(1:end-4) 'SumProd.m'],'w');
end
Header = ['function dy = ' filename(1:end-4) 'SumProd(t,y,g,n,k,inh,stim)'];
SecondLine = ['dy = zeros(' num2str(m.nums) ',1);'];
fprintf(fid,'%s \n %s \n',Header,SecondLine);

for eachSpec = 1:m.nums
    localModel = m.interMat(:,m.interMat(eachSpec,:) == 1);
    localNot = m.notMat(:,m.interMat(eachSpec,:) == 1);
    localParams = m.paramMat(:,m.interMat(eachSpec,:) == 1);
    if isempty(localModel)
        ReacString = ['dy(' num2str(eachSpec) ') = - stim(' num2str(eachSpec) ').*inh(' num2str(eachSpec) ').*y(' num2str(eachSpec) ');'];
    else
        if size(localModel,2) > 1
            ReacString = ['dy(' num2str(eachSpec) ') = stim(' num2str(eachSpec) ').*(inh(' num2str(eachSpec) ').*(QQLMEvalLogSum(['];
        else
            ReacString = ['dy(' num2str(eachSpec) ') = stim(' num2str(eachSpec) ').*(inh(' num2str(eachSpec) ').*('];
        end
        for eachReac = 1:size(localModel,2)
            numIns = nnz(localModel(:,eachReac)==-1);
            if numIns>1 && eachReac == 1
                ReacString = [ReacString 'prod(['];
            elseif numIns>1 && eachReac > 1
                ReacString = [ReacString ', prod(['];
            else
                ReacString = [ReacString ''];
            end
            InputIX = find(localModel(:,eachReac)==-1);
            paramLoc = localParams(localModel(:,eachReac)==-1,eachReac);
            signID = localNot(localModel(:,eachReac)==-1,eachReac)==0;
            for eachIn = 1:numIns
                if signID(eachIn) && eachIn==1 && eachReac ==1
                    ReacString = [ReacString ' 1 - '];
                elseif signID(eachIn) && (eachIn > 1 || eachReac > 1)
                    ReacString = [ReacString ', 1 - '];
                elseif ~signID(eachIn) && (eachIn > 1 || eachReac > 1)
                    ReacString = [ReacString ','];
                end
                ReacString = [ReacString ' g(' num2str(paramLoc(eachIn)) ') .* y(' num2str(InputIX(eachIn)) ').^n(' num2str(paramLoc(eachIn))...
                    ').*(1+k(' num2str(paramLoc(eachIn)) ').^n(' num2str(paramLoc(eachIn)) '))./(y(' num2str(InputIX(eachIn)) ').^n(' num2str(paramLoc(eachIn))...
                    ')+k(' num2str(paramLoc(eachIn)) ').^n(' num2str(paramLoc(eachIn)) '))'];
            end
            if numIns > 1
                ReacString = [ReacString '])'];
            end
        end
        if size(localModel,2) > 1
            ReacString = [ReacString '],2)) - y(' num2str(eachSpec) '));'];
        else
            ReacString = [ReacString ') - y(' num2str(eachSpec) '));'];
        end
    end
    fprintf(fid,'%s\n',ReacString);
end
fclose(fid);
%Assign Parameters
countModels = 1;
weirdKs = [];
paramSet = zeros(0,3);
while countModels <= totalNumMod
    for eachID = 1:numr
        CurrRows = find(IDs==uniqIDs(eachID));
        if length(CurrRows)>1 && ~all(IsAND(CurrRows))
            error('something went wrong with AND gate identification')
        elseif length(CurrRows) > 1
            currAND = cat(1,ANDInfo{3,:})==uniqIDs(eachID);
            CurrRows(CurrRows==ANDInfo{2,currAND})=[];
        end
        for eachIN = 1:length(CurrRows)
            gIX = allGs(countModels,CurrRows(eachIN));
            nIX = allNs(countModels,CurrRows(eachIN));
            kIX = allKs(countModels,CurrRows(eachIN));
            if ~any(all(paramSet(:,1:2)==repmat([Ns{CurrRows(eachIN)}(nIX) Ks{CurrRows(eachIN)}(kIX)],size(paramSet,1),1),2))
                currKParam = fsolve(@(k) calcEC50(Ks{CurrRows(eachIN)}(kIX),Ns{CurrRows(eachIN)}(nIX),k),0.8,optimset('Display','off'));
                paramSet(end+1,:) = [Ns{CurrRows(eachIN)}(nIX) Ks{CurrRows(eachIN)}(kIX) currKParam];
            else
                IDPrevStore = find(all(paramSet(:,1:2)==repmat([Ns{CurrRows(eachIN)}(nIX) Ks{CurrRows(eachIN)}(kIX)],size(paramSet,1),1),2));
                currKParam = paramSet(IDPrevStore(1),3);
            end
            if (currKParam < 0.1 || currKParam > 1) && ~any(weirdKs==currKParam)
                weirdKs(end+1) = currKParam;
                disp(' ')
                disp(['Warning: K Parameter Calculated To be ' num2str(currKParam) ' when n=' num2str(Ns{CurrRows(eachIN)}(nIX))...
                    ' and EC50=' num2str(Ks{CurrRows(eachIN)}(kIX))])
            end
            kMat(countModels,m.paramMat(strcmpi(INs(CurrRows(eachIN)),SpecNames),eachID)) = currKParam;
            nMat(countModels,m.paramMat(strcmpi(INs(CurrRows(eachIN)),SpecNames),eachID)) = Ns{CurrRows(eachIN)}(nIX);
            gMat(countModels,m.paramMat(strcmpi(INs(CurrRows(eachIN)),SpecNames),eachID)) = Gs{CurrRows(eachIN)}(gIX);
        end
    end
    countModels = countModels + 1;
end

m.mFile = [filename(1:end-4) '.m'];
m.mFileSumProd = [filename(1:end-4) 'SumProd.m'];
m.gMat = gMat;
m.nMat = nMat;
m.kMat = kMat;

try
    save(fullfile('Models',[filename(1:end-4) '.mat']),'m')
catch
    disp(' ')
    disp('Saving model in current directory')
    save([filename(1:end-4) '.mat'],'m')
end

function toZero = calcEC50(x,n,k)

toZero = (1 + k^n) * x^n - 0.5 * (k^n + x^n);