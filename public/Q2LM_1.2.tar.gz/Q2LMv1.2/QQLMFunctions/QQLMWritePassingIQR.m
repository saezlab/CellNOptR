function QQLMWritePassingIQR(Res,iqrThresh,varargin)
% QQLMWritePassingIQR(Res,iqrThresh)
%   Writes Experiments in Res that had an inner quartile range of greater
%   than iqrThresh.  SimResExptEnd must have been calculated according to
%   some criteria in the Res arument, for Q2LM or by default for tQLM.  
%   inner quartile range is calculated across all models.
%
% QQLMWritePassingIQR(Res,iqrThresh,true/false)
%   Writes Experiments in Res that had an inner quartile range of greater
%   than iqrThresh.  SimResExptEnd must have been calculated according to
%   some criteria in the Res arument.  innter quartile range is calculated
%   as the third minus the first quartile across all models.  Only writes
%   simples experiments (i.e. combinations are ignored if the single
%   species was sufficient)
%
% QQLMWritePassingIQR(Res,iqrThresh,true/false,SpeciesNames)
%   Writes Experiments in Res that had an inner quartile range of greater
%   than iqrThresh for the Species specified by the cell string Species
%   Names. SimResExptEnd must have been calculated according to
%   some criteria in the Res arument.  innter quartile range is calculated
%   as the third minus the first quartile across all models.  Only writes
%   simples experiments (i.e. combinations are ignored if the single
%   species was sufficient)
%
%   Requres Statistics Toolbox
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  6/27/11

if isfield(Res.Model(1),'TrainedModels')
    mRef = Res.Model(1).TrainedModels;
else
    mRef = Res.Model;
end

if nargin > 2
    onlySimple = varargin{1};
    if nargin == 4
        SpeciesNames = varargin{2};
        SpecKeep = nan(numel(SpeciesNames),1);
        for eachName = 1:numel(SpeciesNames)
            if any(strcmpi(SpeciesNames{eachName},cellstr(mRef.specID)))
                SpecKeep(eachName) = find(strcmpi(SpeciesNames{eachName},cellstr(mRef.specID)));
            else
                disp(' ')
                disp(['Species ' SpeciesNames{eachName} ' not found in model.  It will be igored'])
            end
        end
        SpecKeep(isnan(SpecKeep)) = [];
        if isempty(SpecKeep)
            disp(' ')
            disp('No valid species entered in fourth argument. All will be considered')
            SpecKeep = 1:size(mRef.specID,1);
        end
    else
        SpecKeep = 1:size(mRef.specID,1);
    end
else
    onlySimple = false;
    SpecKeep = 1:size(mRef.specID,1);
end

FilenameUse = [Res.Parameters.Filename '_IQR'];

% Breaks = quantile(Res.SimResExptEnd(:,:,SpecKeep,:),[0.25 0.75],4);
% Break1SimResExpt = Breaks(:,:,:,1);
% Break3SimResExpt = Breaks(:,:,:,2);
% 
% iqr_expt = Break3SimResExpt - Break1SimResExpt;
iqr_expt = iqr(Res.SimResExptEnd(:,:,SpecKeep,:),4);

PassingCombs = iqr_expt > iqrThresh;

specNames = cellstr(mRef.specID);

numPassing = sum(PassingCombs,3);
maxSpecPassed = max(max(numPassing));


fid = fopen(fullfile('Results',FilenameUse),'w');
if fid == -1
    disp(' ')
    disp('Could not find Results folder.  Will make file in current directory')
    fid = fopen(fullfile(FilenameUse),'w');
end
fprintf(fid,'%s\n\n','****************************');
fprintf(fid,'%s\n',['Conditions that maximize IQR for most (' num2str(maxSpecPassed) ' out of ' num2str(length(SpecKeep)) ') species']);
fclose(fid);

currPassingCombs = numPassing == maxSpecPassed;
QQLMWritePassingCombs(currPassingCombs,Res.SimProjExpt,FilenameUse,onlySimple)



for eachSpec = 1:length(SpecKeep)
    currPassingCombs = PassingCombs(:,:,eachSpec);
    if any(any(currPassingCombs))
        fid = fopen(fullfile('Results',FilenameUse),'a');
        if fid == -1
            fid = fopen(fullfile(FilenameUse),'a');
        end
        if eachSpec == 1
            fprintf(fid,'%s\n','Conditions that maximize IQR of each species in the model');
        end
        fprintf(fid,'\n\n%s\n',['Species: ' specNames{SpecKeep(eachSpec)}]);
        fclose(fid);
        QQLMWritePassingCombs(currPassingCombs,Res.SimProjExpt,FilenameUse,onlySimple)
    end
end


