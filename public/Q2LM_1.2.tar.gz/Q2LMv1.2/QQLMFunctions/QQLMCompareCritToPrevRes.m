function ResCrit = QQLMCompareCritToPrevRes(Res,Scenario,CriteriaName)
% Res = QQLMCompareCritToPrevRes(Res,Scenario,CriteriaName)
%   Compares a Criteria to the experiments in Res.SimResExpt.  
%   Criteria can be either a text file or prev loaded structure, but it 
%   has to be the same type (structure or text file) as Scenario, and
%   Scenario must be identical to the one that Res.SimResExpt was used to
%   simulate.  This is a bit redundant but the scenario has to be there so
%   the Criteria can be made compatible for comparison.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11
%   

disp(' ')
disp('*********************************')
disp('QQLM Compare New Crit to Prev Res')

% import scenario if applicable
disp(' ')
disp('Loading Scenario')
if isstruct(Scenario)
    SimProjExpt = Scenario;
    if isstruct(CriteriaName)
        SimProjCrit = CriteriaName;
    else
        error('both scenario and criteria must be the same type: filenames or structures')
    end
elseif ischar(Scenario)
    [SimProjExpt SimProjCrit] = QQLMImportScenario(Scenario,CriteriaName);
else
    error('undefined scenario input type')
end

if isfield(Res,'SimProjExpt')
    disp(' ')
    disp('SimProjExpt both provided in Res and loaded by default.  The Project in Res will be used.')
    SimProjExpt = Res.SimProjExpt;
end

% set parameters to same as Res
Parameters = Res.Parameters;

% set model to same as Res
m = Res.Model;

% check SimProjects and Model for naming consistency
QQLMCompareModelProjNames(m,SimProjExpt);
if ~strcmpi(SimProjCrit(1).typeCrit,'NoFixScen')
    QQLMCompareModelProjNames(m,SimProjCrit);
    disp(' ')
    disp('Model/Scenario names checked out!')
end

% use SimResExpt in Res
SimResExpt = Res.SimResExpt;

disp(' ')
disp('Comparing to Criteria')
ResCrit = QQLMCompareToCriteria(SimResExpt,SimProjExpt,SimProjCrit,m,Parameters);
disp(' ')
disp('Comparison Complete!')



