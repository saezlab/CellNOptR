function SimResComp = QQLMMakeCritProjCompatible(SimResExpt,SimProjCrit,SimResCrit)
% SimResComp =
% QQLMMakeCritProjCompatible(SimResExpt,SimProjCrit,SimResCrit)
%   makes a SimResCrit compatible with a SimResExpt as indicated by
%   SimProjCrit(1).typeCrit by copying it to be the same size as
%   SimResExpt.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

SimResComp = nan(size(SimResExpt,1),size(SimResExpt,2),size(SimResExpt,3),size(SimResCrit,4),size(SimResCrit,5));
if strcmpi(SimProjCrit(1).typeCrit,'AllFixScen')
    % copy
    for eachScen = 1:size(SimResExpt,1)
        SimResComp(eachScen,:,:,:,:) = repmat(SimResCrit(eachScen,:,:,:,:),[1 size(SimResExpt,2) 1 1 1]);
    end
elseif strcmpi(SimProjCrit(1).typeCrit,'SingleFixScen')
    if size(SimProjCrit(1).valueStimuli,1) > 1 || numel(SimProjCrit) > 1
        disp('WARNING: For single fixed scenario as criteria, exactly one fixed scenario should be supplied.  Only using first')
    end
    % copy crit project to be same size
    for eachScen = 1:size(SimResExpt,1)
        SimResComp(eachScen,:,:,:,:) = repmat(SimResCrit(1,:,:,:,:),[1 size(SimResExpt,2) 1 1 1]);
    end
elseif strcmpi(SimProjCrit(1).typeCrit,'Model')
    % copy crit project to be same size
    if size(SimResCrit,1) ~= size(SimResExpt,1) || size(SimResCrit,2) ~= size(SimResExpt,2) || size(SimResCrit,3) ~= size(SimResExpt,3) 
        error('To compare models, they must have the same species in the same order and the same scenario must be used')
    end
    if size(SimResCrit,4) > 1
        disp(' ')
        disp('Multiple models found for comparison.  Experiments will be compared to the median of their prediction')
        SimResCritPick = quantile(SimResCrit,0.5,4);
    else
        SimResCritPick = SimResCrit(:,:,:,1);
    end
    SimResComp = repmat(SimResCritPick,[1 1 1 size(SimResExpt,5)]);
else
    error('typeCrit not supported')
end