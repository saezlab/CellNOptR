function SumCube = QQLMEvalLogSum(x,dim)
% SumCube = QQLMEvalLogSum(outputCubeReorder)
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% Evaluates logical sum of x in the dimension dim.  If no dimension is
% given, the third dimension is evalutated by default

if nargin == 1
    dim = 3;
end

dims = 1:3;
dims(dim) = [];
dimsUse = [dims dim];
x_shape = permute(x,dimsUse);
[dim1 dim2 maxgpo] = size(x_shape);

ProdOrder(:,:,1) = CNOnansum(x_shape,3);
if maxgpo > 1
    for eachGate = 2:maxgpo
        currCombs = nchoosek(1:maxgpo,eachGate);
        currProd = nan(dim1,dim2,size(currCombs,1));
        for eachComb = 1:size(currCombs,1)
            currProd(:,:,eachComb) = prod(x_shape(:,:,currCombs(eachComb,:)),3);
        end
        ProdOrder(:,:,eachGate) = CNOnansum(currProd,3);
    end
    SumCube = CNOnansum(ProdOrder(:,:,1:2:maxgpo),3) - CNOnansum(ProdOrder(:,:,2:2:maxgpo),3);
else
    SumCube = ProdOrder(:,:,1);
end
SumCube(all(isnan(x_shape),3)) = NaN;

SumCube = permute(SumCube,[find(dimsUse==1) find(dimsUse==2) find(dimsUse==3)]);