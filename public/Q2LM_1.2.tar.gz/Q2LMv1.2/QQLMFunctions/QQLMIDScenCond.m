function [names values] = QQLMIDScenCond(ScenCond)
% [names values] = QQLMIDScenCond(ScenCond) reads the specified environment
%   from the Scenario folder.  ScenCond is a cell of strings with the form
%   'species1=x,species2=x2'. The output names contains a cellstr with the
%   names of m species included in all environments, and the output
%   values is a n x m matrix of the value of each species for the n
%   environments.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

names = QQLMGuessCueNames(ScenCond);

numCond = numel(names);
values = zeros(numel(ScenCond),numCond);
for eachScen=1:numel(ScenCond)
    %figure out what the value of each Cond is in that label
    for eachCond=1:numCond
        startIx=findstr(names{eachCond},ScenCond{eachScen});
        equalsSign=findstr('=',ScenCond{eachScen}(startIx:end));
        commas=findstr(',',ScenCond{eachScen}(startIx:end));
        %based on the type of string, store the value of the Cond in a
        %matrix with the first dimension corresponding to the label number.
        % This will be useful when assigning to each experiment
        if isempty(startIx)
            values(eachScen,eachCond)=0;
        elseif isempty(equalsSign) && isempty(commas)
            values(eachScen,eachCond)=1;
        elseif isempty(equalsSign)
            values(eachScen,eachCond)=1;
        elseif isempty(commas)
            values(eachScen,eachCond)=str2double(ScenCond{eachScen}(startIx+equalsSign(1):end));
        elseif equalsSign(1) > commas(1)
            values(eachScen,eachCond)=1;
        else
            values(eachScen,eachCond)=str2double(ScenCond{eachScen}(startIx+equalsSign(1):startIx+commas(1)-2));
        end
        clear startIx
        clear equalsSign
        clear commas
    end
end