function Parameters = QQLMLoadParameters(filename)
% Parameters = QQLMLoadParameters(filename)
%   Loads parameters in txt filename.  Builds Structure outward.  The
%   Parameters field contains fields named in the first column of the txt
%   file, with corresponding values in the second column.  The
%   Parameters.Simulation field contains subfields named in the third
%   column of the txt file with corresponding values in the fourth column.
%   The Parameters.Simulation.SimEngSpecific field contains subfields named 
%   in the fifth column of the txt file with corresponding values in the 
%   sixth column.  These values must be executable statements.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

fid = fopen(fullfile('Parameters',filename));
if fid == -1
    fid = fopen(fullfile(filename));
    if fid == -1
        error('no parameters file found in the "Parameters" folder or MatLab path')
    end
end
InputCols = textscan(fid,'%q %q %q %q %q %q','delimiter','\t','CommentStyle','#');
fclose(fid);

for i = 1:numel(InputCols{1})
    if ~isempty(InputCols{1}{i})
        Parameters.(InputCols{1}{i}) = InputCols{2}{i};
    end
end
for i = 1:numel(InputCols{3})
    if ~isempty(InputCols{3}{i})
        if any(regexpi(InputCols{4}{i},'@')) || ~isnan(str2double(InputCols{4}{i}))
            Parameters.Simulation.(InputCols{3}{i}) = eval(InputCols{4}{i});
        else
            Parameters.Simulation.(InputCols{3}{i}) = InputCols{4}{i};
        end
    end
end

for i = 1:numel(InputCols{5})
    if ~isempty(InputCols{5}{i})
        try
            Parameters.Simulation.SimEngSpecific.(InputCols{5}{i}) = eval(InputCols{6}{i});
        catch
            disp(' ')
            disp(['Matlab did not recognize Parameter as an evaluatable statement' InputCols{5}{i} '. It will be entered as if, which might cause problems later'])
            Parameters.Simulation.SimEngSpecific.(InputCols{5}{i}) = InputCols{6}{i};
        end
    end
end