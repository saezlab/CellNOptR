function [g n k paramIx] = QQLMFindTFParameter(m,InSpec,OutSpec)
% [g n k] = QQLMFindTFParameter(m,InSpec,OutSpec)
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
InIx = find(strcmpi(InSpec,cellstr(m.specID)));
if isempty(InIx)
    error(['Species ' InSpec ' not found in model'])
end

OutIx = find(strcmpi(OutSpec,cellstr(m.specID)));
if isempty(OutIx)
    error(['Species ' OutSpec ' not found in model'])
end

finalCubeSurr = m.finalCube;
finalCubeSurr(m.ignoreCube) = NaN;
possInt = find(m.maxIx == OutIx);
paramIx = [];
for eachPossInt = 1:length(possInt)
    if any(finalCubeSurr(possInt(eachPossInt),:) == InIx)
        paramIx(end+1:end+nnz(finalCubeSurr(possInt(eachPossInt),:) == InIx)) = m.paramCube(possInt(eachPossInt),finalCubeSurr(possInt(eachPossInt),:) == InIx);
    end
end

if isempty(paramIx)
    disp('No transfer function found between those two species')
    g = [];
    n = [];
    k = [];
else
    if length(paramIx) > 1
        disp('More than one transfer function found between those two species')
    end
    g = m.gMat(:,paramIx);
    n = m.nMat(:,paramIx);
    k = m.kMat(:,paramIx);
end
    