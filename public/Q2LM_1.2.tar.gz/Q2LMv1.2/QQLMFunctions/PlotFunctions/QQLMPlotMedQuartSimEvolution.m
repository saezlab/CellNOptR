function QQLMPlotMedQuartSimEvolution(m,SimResExpt)
% QQLMPlotAllTimeCourse(m,SimResExpt)
%   Plots timecourse of SimResExpt for all species in m (which
%   SimResExpt is assumed to have been simulated by).  For each 
%   Dim1 of SimResExpt, makes a new figure with subplots for each species 
%   in the model (Dim3 of SimResExpt), plotting value across each time step 
%   (Dim4 of SimResExpt) for each model (Dim5 of SimResExpt, given 
%   different line styles) and each Condition (Dim2 of SimResExpt, given 
%   different colors).
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

 Breaks = quantile(SimResExpt,[0.25 0.5 0.75],5);
Break1SimResExpt = Breaks(:,:,:,:,1);
MedSimResExpt = Breaks(:,:,:,:,2);
Break3SimResExpt = Breaks(:,:,:,:,3);
Quart1SimResExpt = MedSimResExpt - Break1SimResExpt;
Quart3SimResExpt = Break3SimResExpt - MedSimResExpt;


%color choices for experiments
ColorsPick = cell(5,1);
ColorsPick{1} = 'k-';
ColorsPick{2} = 'b-';
ColorsPick{3} = 'm-';
ColorsPick{4} = 'g-';
ColorsPick{5} = 'c-';
ColorsPick{6} = 'k--';
ColorsPick{7} = 'b--';
ColorsPick{8} = 'm--';
ColorsPick{9} = 'g--';
ColorsPick{10} = 'c--';
ColorsPick{11} = 'k:';
ColorsPick{12} = 'b:';
ColorsPick{13} = 'm:';
ColorsPick{14} = 'g:';
ColorsPick{15} = 'c:';
ColorsPick{16} = 'k-.';
ColorsPick{17} = 'b-.';
ColorsPick{18} = 'm-.';
ColorsPick{19} = 'g-.';
ColorsPick{20} = 'c-.';
ColorsPick{21} = 'ko';
ColorsPick{22} = 'bo';
ColorsPick{23} = 'mo';
ColorsPick{24} = 'go';
ColorsPick{25} = 'co';

%assign a color to each experiment
ColorsStr = cell(size(SimResExpt,2),1);
thisComb = 1;
ixCol = 1;
while thisComb <= size(SimResExpt,2)
    ColorsStr{thisComb} = ColorsPick{ixCol};
    ixCol = ixCol+1;
    if floor(ixCol/numel(ColorsPick))==ixCol/numel(ColorsPick)
        ixCol = 1;
    end
    thisComb = thisComb+1;
end

%for each environment
for eachScen = 1:size(SimResExpt,1)
    figure('Name',['Time Course SimResExpt for Environment #' num2str(eachScen)])
    %plot all the species
    for eachSpec = 1:size(SimResExpt,3)
        subplot(ceil(sqrt(size(SimResExpt,3))),ceil(sqrt(size(SimResExpt,3))),eachSpec)
        hold on
        for eachComb = 1:size(SimResExpt,2)
            errorbar((1:length(MedSimResExpt(eachScen,eachComb,eachSpec,:)))-1,...
                squeeze(real(MedSimResExpt(eachScen,eachComb,eachSpec,:))),...
                squeeze(real(Quart1SimResExpt(eachScen,eachComb,eachSpec,:))),...
                squeeze(real(Quart3SimResExpt(eachScen,eachComb,eachSpec,:))),ColorsStr{eachComb})
        end
        xlabel('Simulation Step')
        currSpec = m(1).specID(eachSpec,:);
        if any(regexpi(currSpec,' '))
            IxDel = regexpi(currSpec,' ');
            currSpec(IxDel(1):end) = [];
        end
        ylabel({currSpec; 'Value'})
        set(gca,'YLim',[0 1])
        hold off
    end
end



