function QQLMPredictTF(m,Parameters,TFSpec)
% QQLMPredictTF(m,Parameters,TFSpec)
%
% m is the model (or family of models).
% Parameters: Simulation parameters
% TFSpec has three fields:
%   Inputs: cell of input species
%   Output: string with single output species
%   Endpoint: how to calculate endpoint (only for non-trained models)
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%

NumIns = numel(TFSpec.Inputs);

if numel(m) > 1 && isfield(m,'kMat')
    disp(' ')
    disp('It looks like this might not be a trained model because it has',...
        'the field kMat, but numel(m) > 1 so it will be considered a trained model')
    typeSim = 'tQLM';
    mRef = m{1};
elseif numel(m) == 1 && isfield(m,'kMat')
    typeSim = 'QQLM';
    mRef = m;
else
    typeSim = 'tQLM';
    mRef = m{1};
end

ixOut = find(strcmpi(TFSpec.Output,cellstr(mRef.specID)));
if isempty(ixOut)
    error('No output found in model')
end

if NumIns > 1
    CombPlots = nchoosek(1:NumIns,2);
    NumPlots = size(CombPlots,1);
    disp(' ')
    disp(['Will create ' num2str(NumPlots) ' Surface Plots'])
    % initialize project
    currSimProj.valueStimuli = (QQLMfullfact([11 11]) - 1)*0.1;
    currSimProj.namesInhibitors = {};
    currSimProj.valueInhibitors = [];
    % simulate and plot
    for eachPlot = 1:NumPlots
        [currSimProj.namesStimuli{1:2,1}] = deal(TFSpec.Inputs{CombPlots(eachPlot,:)});
        if strcmpi(typeSim,'QQLM')
            if any(regexpi(Parameters.ModelType,'cFL')) || any(regexpi(Parameters.ModelType,'Fuzzy'))
                AllOuts = QQLMSimulateCFLScenario(m,currSimProj,Parameters);
            elseif any(regexpi(Parameters.ModelType,'ODe'))
                AllOuts = QQLMSimulateODEScenario(m,currSimProj,Parameters);
            end
            SimRes = QQLMMakeRepTimeVal(AllOuts,struct('EndPoint',TFSpec.EndPoint),Parameters);
        elseif strcmpi(typeSim,'tQLM')
            SimRes = tQLMSimulateScenario(m,currSimProj,Parameters);
        end
        outMat = permute(SimRes(1,:,ixOut,:),[2 4 3 1]);
        quartOut = quantile(outMat,[0.25 0.5 0.75],2);
        xVec = 0:0.1:1;
        yVec = 0:0.1:1;
        surfZ_1 = reshape(quartOut(:,1),[11 11]);
        surfZ_2 = reshape(quartOut(:,2),[11 11]);
        surfZ_3 = reshape(quartOut(:,3),[11 11]);
        figure('Name',['TF Plot Number ' num2str(eachPlot)])
        surf(xVec,yVec,surfZ_1,'FaceAlpha',0.4)
        hold on
        surf(xVec,yVec,surfZ_2)
        surf(xVec,yVec,surfZ_3,'FaceAlpha',0.4)
        xlabel(currSimProj.namesStimuli{1});
        ylabel(currSimProj.namesStimuli{2});
        zlabel(TFSpec.Output);
        hold off
    end
else
    NumPlots = 1;
    % initialize project
    currSimProj.valueStimuli = [0:0.1:1]';
    currSimProj.namesInhibitors = {};
    currSimProj.valueInhibitors = [];
    % simulate and plot
    currSimProj.namesStimuli = TFSpec.Inputs;
    if strcmpi(typeSim,'QQLM')
        if any(regexpi(Parameters.ModelType,'cFL')) || any(regexpi(Parameters.ModelType,'Fuzzy'))
            AllOuts = QQLMSimulateCFLScenario(m,currSimProj,Parameters);
        elseif any(regexpi(Parameters.ModelType,'ODe'))
            AllOuts = QQLMSimulateODEScenario(m,currSimProj,Parameters);
        end
        SimRes = QQLMMakeRepTimeVal(AllOuts,struct('EndPoint',TFSpec.EndPoint),Parameters);
    elseif strcmpi(typeSim,'tQLM')
        SimRes = tQLMSimulateScenario(m,currSimProj,Parameters);
    end
    outMat = permute(SimRes(1,:,ixOut,:),[2 4 3 1]);
    quartOut = quantile(outMat,[0.25 0.5 0.75],2);
    xVec = 0:0.1:1;
    figure('Name','TF Plot Number 1')
    errorbar(currSimProj.valueStimuli,quartOut(:,2),quartOut(:,2)-quartOut(:,1),quartOut(:,3)-quartOut(:,2),'g-o','LineWidth',3)
    xlabel(currSimProj.namesStimuli{1});
    ylabel(TFSpec.Output);
    hold off
end
