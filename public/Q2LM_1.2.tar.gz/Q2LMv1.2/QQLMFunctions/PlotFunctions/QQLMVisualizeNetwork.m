function QQLMVisualizeNetwork(Model, varargin)
%       CNOVisualizeNetwork(Model, 'filename')
% OR    CNOVisualizeNetwork(Model)
% OR    CNOVisualizeNetwork(Model, SimProject, 'filename')
% This is just a wrapper for CNOVisualizeNetwork1, which is a CellNOp
% function.  If you don't have CellNOpt, this function will not work.
% Type 'help CNOVisualizeNetwork1' for more options.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

penwidths = ones(1,size(Model.interMat,2));
filename = 'CNONetwork';
compress = false;
outputtype='pdf';

if nargin == 1
    Opt = struct();
elseif nargin == 2
    if ischar(varargin{1})
        filename = varargin{1};
        Opt = struct('edge_penwidth',penwidths,...
            'filename',filename,'compress',compress,'sortby',@mean,'preamble','size="8.5,11";');
    elseif isstruct(varargin{1})
        CNOProject = varargin{1};
        CNOProject.namesSignals = cellstr(Model.specID);
        CNOProject.indexSignals = 1:size(Model.specID,1);
        
        CNOProject.valueInhibitors = 1-CNOProject.valueInhibitors;
        CNOProject.timeCues = 0;
        CNOProject.timeSignals = [0; 1];
        CNOProject.valueSignals=zeros(size(CNOProject.valueStimuli,1),numel(CNOProject.namesSignals));
        
        CNOProject.indexStimuli = nan(1,numel(CNOProject.namesStimuli));
        for i = 1:numel(CNOProject.namesStimuli)
            CNOProject.indexStimuli(i) = find(strcmpi(CNOProject.namesStimuli{i},cellstr(Model(1).specID)));
        end
        CNOProject.indexInhibitors = nan(1,numel(CNOProject.namesInhibitors));
        for i = 1:numel(CNOProject.namesInhibitors)
            CNOProject.indexInhibitors(i) = find(strcmpi(CNOProject.namesInhibitors{i},cellstr(Model(1).specID)));
        end
        Opt = struct('CNOProject',CNOProject,'edge_penwidth',penwidths,...
            'filename',filename,'compress',compress,'sortby',@mean,'preamble','size="8.5,11";');
    end
elseif nargin == 3
    CNOProject = varargin{1};
    CNOProject.namesSignals = cellstr(Model.specID);
    CNOProject.indexSignals = 1:size(Model.specID,1);
    
    CNOProject.valueInhibitors = 1-CNOProject.valueInhibitors;
    CNOProject.timeCues = 0;
    CNOProject.timeSignals = [0; 1];
    CNOProject.valueSignals=zeros(size(CNOProject.valueStimuli,1),numel(CNOProject.namesSignals));
    
    CNOProject.indexStimuli = nan(1,numel(CNOProject.namesStimuli));
    for i = 1:numel(CNOProject.namesStimuli)
        CNOProject.indexStimuli(i) = find(strcmpi(CNOProject.namesStimuli{i},cellstr(Model(1).specID)));
    end
    CNOProject.indexInhibitors = nan(1,numel(CNOProject.namesInhibitors));
    for i = 1:numel(CNOProject.namesInhibitors)
        CNOProject.indexInhibitors(i) = find(strcmpi(CNOProject.namesInhibitors{i},cellstr(Model(1).specID)));
    end
    filename = varargin{2};
    Opt = struct('CNOProject',CNOProject,'edge_penwidth',penwidths,...
        'filename',filename,'compress',compress,'sortby',@mean,'preamble','size="8.5,11";');
end

if nnz(abs(Model.interMat)>1)>0
    disp(' * the model contains multilevels. ');
    disp(' * The visualization of the model will not consider the different levels.')
    disp(' ')
    Model.interMat=sign(Model.interMat);
end

try
    [A,S] = CNOVisualizeNetwork1(Model,Opt);
    graph2dot(A,S);
catch
    disp(' ')
    disp('Network Visualization failed.  Do you have the CellNOpt functions CNOVisualizeNetwork1 and graph2dot on the current path?')
    return
end

if strcmp(outputtype,'eps')
    [error dum]=system(['dot -Teps ' filename '_stimuli_mean.dot -o ' filename '.eps']);
    if error
        [a b]=system(['dot -Tps ' filename '_stimuli_mean.dot -o ' filename '.ps']);
        [a b]=system([' ps2eps ' filename]);
    end
elseif strcmp(outputtype,'ps')
    [a b]=system(['dot -Tps ' filename '_stimuli_mean.dot -o ' filename '.ps']);
else
    [a b]=system(['dot -Tpdf ' filename '_stimuli_mean.dot -o ' filename '.pdf']);
end

%if ismac
%    [a b]=system(['open ' filename '.pdf &']);
%elseif isunix
%    [a b]=system(['acroread ' filename '.pdf &']);
%end