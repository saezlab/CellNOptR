function QQLMPlotAllSimEvolution(m,SimResExpt)
% QQLMPlotAllTimeCourse(m,SimResExpt)
%   Plots timecourse of SimResExpt for all species in m (which
%   SimResExpt is assumed to have been simulated by).  For each
%   Dim1 of SimResExpt, makes a new figure with subplots for each species
%   in the model (Dim3 of SimResExpt), plotting value across each time step
%   (Dim4 of SimResExpt) for each model (Dim5 of SimResExpt, given
%   different line styles) and each Condition (Dim2 of SimResExpt, given
%   different colors).
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

%color choices for experiments
ColorsPick = cell(5,1);
ColorsPick{1} = 'k';
ColorsPick{2} = 'b';
ColorsPick{3} = 'm';
ColorsPick{4} = 'g';
ColorsPick{5} = 'c';

%line styles for models
LinesPick = cell(5,1);
LinesPick{1} = '-';
LinesPick{2} = '--';
LinesPick{3} = ':';
LinesPick{4} = '-.';
LinesPick{5} = 'o';

%assign a color to each experiment
ColorsStr = cell(size(SimResExpt,2),1);
thisComb = 1;
ixCol = 1;
while thisComb <= size(SimResExpt,2)
    ColorsStr{thisComb} = ColorsPick{ixCol};
    ixCol = ixCol+1;
    if floor(ixCol/numel(ColorsPick))==ixCol/numel(ColorsPick)
        ixCol = 1;
    end
    thisComb = thisComb+1;
end

%assign a line style to each model
LinesStr = cell(size(SimResExpt,5),1);
thisMod = 1;
ixLine = 1;
while thisMod <= size(SimResExpt,5)
    LinesStr{thisMod} = LinesPick{ixLine};
    ixLine = ixLine+1;
    if floor(ixLine/numel(LinesPick))==ixLine/numel(LinesPick)
        ixLine = 1;
    end
    thisMod = thisMod+1;
end

%for each environment
for eachScen = 1:size(SimResExpt,1)
    figure('Name',['Time Course SimResExpt for Environment #' num2str(eachScen)])
    %plot all the species
    for eachSpec = 1:size(SimResExpt,3)
        subplot(ceil(sqrt(size(SimResExpt,3))),ceil(sqrt(size(SimResExpt,3))),eachSpec)
        hold on
        for eachModel = 1:size(SimResExpt,5)
            for eachComb = 1:size(SimResExpt,2)
                plot((1:length(SimResExpt(eachScen,eachComb,eachSpec,:,eachModel)))-1,squeeze(real(SimResExpt(eachScen,eachComb,eachSpec,:,eachModel))),[ColorsStr{eachComb} LinesStr{eachModel}])
            end
        end
        xlabel('Simulation Step')
        currSpec = m(1).specID(eachSpec,:);
        if any(regexpi(currSpec,' '))
            IxDel = regexpi(currSpec,' ');
            currSpec(IxDel(1):end) = [];
        end
        ylabel({currSpec; 'Value'})
        set(gca,'YLim',[0 1])
        hold off
    end
end



