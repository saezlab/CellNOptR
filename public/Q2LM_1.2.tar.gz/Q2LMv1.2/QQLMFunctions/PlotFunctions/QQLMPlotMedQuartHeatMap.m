function QQLMPlotMedQuartHeatMap(m,SimResExptComp)
% QQLMPlotAllTimeCourse(m,SimResExptComp)
%   Plots timecourse of SimResExptComp for all species in m (which
%   SimResExpt is assumed to have been simulated by).  For each 
%   Dim1 of SimResExpt, makes a new figure with subplots for each species 
%   in the model (Dim3 of SimResExptComp), plotting the first, second, and 
%   third quartile calculated across models (Dim4 of SimResExptComp).
%   Each environment (Dim1 of SimResExptComp) is plotted in a different 
%   figure and each experiment (Dim2 of SimResExptComp) in a different row 
%   of each plot. 
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

Breaks = quantile(SimResExptComp,[0.25 0.5 0.75],4);
Break1SimResExpt = Breaks(:,:,:,1);
MedSimResExpt = Breaks(:,:,:,2);
Break3SimResExpt = Breaks(:,:,:,3);

MaxUpQuart = max(max(max(max(Breaks))));
MinLowQuart = min(min(min(min(Breaks))));

%for each environment
for eachScen = 1:size(SimResExptComp,1)
    figure('Name',['Time Course SimResExpt for Environment #' num2str(eachScen)])
    %plot all the species
    for eachSpec = 1:size(SimResExptComp,3)
        subplot(ceil(sqrt(size(SimResExptComp,3))),ceil(sqrt(size(SimResExptComp,3))),eachSpec)
        hold on
        title(m(1).specID(eachSpec,:))
        imagesc([permute(Break1SimResExpt(eachScen,:,eachSpec),[2 1 3])...
            permute(MedSimResExpt(eachScen,:,eachSpec),[2 1 3])...
            permute(Break3SimResExpt(eachScen,:,eachSpec),[2 1 3])],[MinLowQuart MaxUpQuart])
        colormap('hot')
        hold off
    end
end
if size(SimResExptComp,3) ~= ceil(sqrt(size(SimResExptComp,3)))^2
    subplot(ceil(sqrt(size(SimResExptComp,3))),ceil(sqrt(size(SimResExptComp,3))),size(SimResExptComp,3)+1)
    imagesc(0,[MinLowQuart MaxUpQuart])
    colorbar
end


