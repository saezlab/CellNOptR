function NSD = CNOnanstd(varargin)
%CNO implementation of NANSTD: Standard deviation, ignoring NaNs.
%   Y = CNONANSTD(X) returns the sample standard deviation of the values in X,
%   treating NaNs as missing values. It normalizes Y by (N-1), where N is 
%   the sample size.  This is the Bessel Correction
%
%   Y = CNONANSTD(X,1) has no meaning for CNOnanstd.  We did not implement
%   this version but kept the input order consistent with MatLab's
%   implementations
%
%   Y = CNONANSTD(X,[],DIM) takes the standard deviation along dimension
%   DIM of X.
%

X = varargin{1};

if isempty(X) || nnz(~isnan(X)) == 0
    NSD = NaN;
    return
end

if nargin ~= 3
    DIM = find(size(X)~=1,1,'first');
    if isempty(DIM)
        DIM =1;
    end
elseif nargin == 2
    error('Y = CNONANSTD(X,1) has no meaning for CNOnanstd.  We did not implement this version but kept the input order consistent with the MatLab implementation')
else
    DIM = varargin{3};
end

NM = CNOnanmean(X,DIM);

repVec = ones(1,length(size(X)));
repVec(DIM) = size(X,DIM);
Diff = X-repmat(NM,repVec);
Diff(isnan(X)) = 0;
X_num = sum(~isnan(X),DIM)-1;
NSD = sqrt(sum((Diff).^2,DIM)./X_num);
NSD(X_num==0)=0;
NSD(X_num<0)=NaN;
