function output=CNOgainTF_Prod(x,k,n,g,ixNeg)
% output=CNOhillNonNorm_Prod(x,k,n,g,ixNeg)
% mf2 = g.*( x.^n ./ (x.^n+k.^n) ).* (1+k.^n) ;
% transfer function in fuzzy simulation
% Contributed by Melody K Morris Jan 2011

mf2 = g.* x;

mf2(ixNeg) = g(ixNeg) - mf2(ixNeg);
mf2Rep = mf2;
mf2Rep(isnan(mf2)) = 1;
output = prod(mf2Rep,3); 
output(all(isnan(mf2),3)) = nan;