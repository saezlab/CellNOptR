function dString = CNOunidrnd(N,MM,NN)
% CNOunidrnd Random arrays from the discrete uniform distribution.
% CNO replacement of Matlab's unidrnd in Statistics Toolbox.
%     R = CNOunidrnd(N,MM,NN) returns a 2-D matrix of random numbers chosen   
%     uniformly from the set {1, 2, 3, ... ,N}..
 
if nargin ~= 3
    error('CNOunidrnd is not identical to unidrnd.  It requires three inputs')
end

randString = rand(MM,NN);
dString = nan(MM,NN);
for i = 1:N
    dString(randString <= i/N & randString > (i-1)/N) =  i;
end

