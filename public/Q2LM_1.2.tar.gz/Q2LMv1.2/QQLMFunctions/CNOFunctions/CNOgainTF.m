function output=CNOgainTF(x,k,n,g,ixNeg)
% tranfer function output = g.*( x.^n ./ (x.^n+k.^n) ).* (1+k.^n)
% contributed by Melody K Morris Jan 2011
mf2 = g.* x;

mf2(ixNeg) = g(ixNeg) - mf2(ixNeg);

output = min(mf2,[],3); 