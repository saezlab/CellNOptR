function NS = CNOnansum(varargin)
%  CNO implementation of MatLab's NANSUM: Sum, ignoring NaNs.
%     Y = CNONANSUM(X, DIM) returns the sum of X along dimension
%     DIM, treating NaNs as missing values. If no DIM is provided, the 
%     DIM to use is determined by MATLAB's sum fn..

X = varargin{1};

X(isnan(X)) = 0;
if nargin ~= 2
    NS = sum(X);
else
    NS = sum(X,varargin{2});
end


