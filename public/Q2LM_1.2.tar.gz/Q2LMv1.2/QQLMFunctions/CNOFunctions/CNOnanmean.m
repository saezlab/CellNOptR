function NM = CNOnanmean(varargin)
%  CNO implementation of MatLab's NANMEAN: Mean value, ignoring NaNs.
%     M = CNONANMEAN(X,DIM) returns the sample mean of X along dimension
%     DIM, treating NaNs as missing values. If no DIM is provided, the 
%     DIM to use is determined by MATLAB's sum fn.
%  

X = varargin{1};

X_ig = X;
X_ig(isnan(X)) = 0;
if nargin ~= 2
    X_num = sum(~isnan(X));
    NM = sum(X_ig)./X_num;
else
    DIM = varargin{2};
    X_num = sum(~isnan(X),DIM);
    NM = sum(X_ig,DIM)./X_num;
end
NM(isinf(NM)) = NaN;
