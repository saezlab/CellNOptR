function output=CNOhillNonNorm(x,k,n,g,ixNeg)
% tranfer function output = g.*( x.^n ./ (x.^n+k.^n) ).* (1+k.^n)
% contributed by Melody K Morris Jan 2011
mf2 = g.*( x.^n ./ (x.^n+k.^n) ).* (1+k.^n) ;

mf2(ixNeg) = 1 - mf2(ixNeg);

output = min(mf2,[],3); 