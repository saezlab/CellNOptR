function outputCompare=QQLMSimEngCFL_Max_Solve(m,SimProj,varargin)
% outputCompare=QQLMSimEngCFL(m,SimProj) or
% outputCompare=QQLMSimEngCFL(m,SimProj, Parameters)
%
% takes a model created by QQLM and simulates it with the conditions
% specified by SimProj.  Best called in QQLMSimulateCFLScenario because
% some processing of SimProj usually needs to take place to make it ready
% for simulation.
%
% Inputs:
%   m: Model with fields kCube, nCube, gCube, ixNeg, maxIx, interMat,
%       finalCube, and ignoreCube
%   SimProj: SimProject with fields valueStimuli, valueInhibitors,
%       indexStimuli, indexInhibitors
%   Parameters (optional): Tolerance, MultSpecToSS, and tfun
%
% Output:
% outputCompare: 3-D matrix with Simulation Result.
%   Dimension 1: Condition (value and Stim)
%   Dimension 2: Species (in model)
%   Dimension 3: Simulation step
%
% See "FuzzySimulationScheme.pdf" in doc for explanation of how this works.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software edited from simulator originally
% written for CellNOpt.  5/4/11


%% Pre-processing

% count some things
[numSpecies numFisFiles]=size(m.interMat);
numExpt=max(size(SimProj.valueStimuli,1),size(SimProj.valueInhibitors,1));

% replicate and reorder Cubes to be compatible with others
kCube=repmat(m.kCube,[1 1 numExpt]);
kCube=permute(kCube,[3 1 2]);
nCube=repmat(m.nCube,[1 1 numExpt]);
nCube=permute(nCube,[3 1 2]);
gCube=repmat(m.gCube,[1 1 numExpt]);
gCube=permute(gCube,[3 1 2]);
ixNeg=repmat(m.ixNeg,[1 1 numExpt]);
ixNeg=permute(ixNeg,[3 1 2]);
ixNeg=logical(ixNeg);


%find the number of gates that specify each species as an output.  This is
%necessary to be able to use the vectorized max function.
endIx=nan(1,numSpecies);
for species=1:numSpecies
    endIx(species)=length(find(m.maxIx==species));
end
maxgpo=max(endIx);

% set stopping conditions based on parameters (optional to provide)
if nargin==3 && ~isempty(varargin{1})
    testMat = varargin{1}.Tolerance*ones(numExpt, numSpecies);
    multSpecToSS = varargin{1}.MultSpecToSS;
    fracSpecToSS = varargin{1}.FracSpecToSS;
    tfun = varargin{1}.tfun;
else
    testMat=1E-3*ones(numExpt, numSpecies);
    multSpecToSS = 5;
    fracSpecToSS = 0.5;
    tfun = @CNOhillNonNorm;
end


%set initial values and override those values with user-defined
%cues or inhibitted species
% set initial contion mat
if isfield(m,'initValues')
    initValues(:,:)=m.initValues;
elseif isfield(m,'specDefault')
    initValues=repmat(m.specDefault',size(SimProj.valueStimuli,1),1);
else
    initValues = nan(numExpt,numSpecies);
end
% overwrite with stimuli
if ~isempty(SimProj.indexStimuli)
    initValues(:,SimProj.indexStimuli)=SimProj.valueStimuli(:,:,1);
end
% overwrite with inhibitted
if ~isempty(SimProj.indexInhibitors)
    initValues(:,SimProj.indexInhibitors)=SimProj.valueInhibitors(:,:,1).*initValues(:,SimProj.indexInhibitors);
end

newInput=initValues;

%initialize variables for main loop
outputCubeReorder=nan(numExpt , numSpecies , maxgpo);

termCheckOne=1;
termCheckTwo=1;
count=1;
outputCompare = newInput;
%main loop
while termCheckOne && termCheckTwo
    outputPrev=newInput;
    %evaluate each AND and activation/inhibition gates for each experiment.
    %Half the time is spent here
    
    % pull out inputs to the gates
    tempStore = outputPrev(:,m.finalCube);
    % if the pulled out value was a 'dummy' value, replace it with Nan? so
    % that it is ignored in the min (maximum value is one)
    tempStore(:,m.ignoreCube) = NaN;
    % invert inhibitory interactions
    outputCube=tfun(reshape(tempStore,numExpt,numFisFiles,m.maxipg),kCube,nCube,gCube,ixNeg);
    
    %re-distribute outputs to matrix that contains possible outputs for
    %each species for each experiment.  Almost half the time is spent here
    for spec=1:numSpecies
        if ~isnan(endIx(spec))
            outputCubeReorder(:,spec,1:endIx(spec))=outputCube(:,m.maxIx==spec);
        end
    end
    %evaluate OR gates by taking max
    newInput = max(outputCubeReorder,[],3);
    
    %this part checks that none the cues and
    %inhibitted species have been violated.
    if ~isempty(SimProj.indexStimuli)
        newInput(:,SimProj.indexStimuli)=max(newInput(:,SimProj.indexStimuli), SimProj.valueStimuli(:,:,1));
    end
    
    if ~isempty(SimProj.indexInhibitors)
        newInput(:,SimProj.indexInhibitors)=SimProj.valueInhibitors(:,:,1).*newInput(:,SimProj.indexInhibitors);
    end
    
    %Replace Nans with zeros.  This keeps the simulation from not
    %converging when there are unconnected species.
    newInputComp = newInput;
    newInputComp(isnan(newInput)) = 0;
    outputPrevComp = outputPrev;
    outputPrevComp(isnan(outputPrev)) = 0;
    
    %check termination condition
    % first check that it's stabilized as a value or nan
    termCheckOne=~all(all(abs((outputPrevComp-newInputComp))<testMat)) || ~all(all(isnan(outputPrev)==isnan(newInput)));
    % then just see if it's been going on too long
    termCheckTwo=count < numSpecies*multSpecToSS;
    count=count+1;
    % save output
    outputCompare(:,:,count) = newInput;
end


if ~all(all(abs((outputPrevComp-newInputComp))<testMat)) || ~all(all(isnan(outputPrev)==isnan(newInput)))
    lastEntry = newInput;
    lastEntry(isnan(lastEntry)) = 0;
    % go back many steps to look for stability
    checkInt = false(size(outputCompare,1),size(outputCompare,2),ceil(numSpecies*fracSpecToSS)+1);
    ixend = size(outputCompare,3);
    for i = 0:ceil(numSpecies*fracSpecToSS)
        ix1 = ixend - i;
        ix2 = ixend - (i+1);
        checkInt(:,:,i+1) = abs((outputCompare(:,:,ix1)-outputCompare(:,:,ix2)))<testMat;
    end
    % if any have changed, it might not have stabilized and is thus
    % replaced with the average for initial guess.
    toTakeMean = outputCompare(:,:,ixend-(ceil(numSpecies*fracSpecToSS)+1):ixend);
    meanAllSpec = CNOnanmean(toTakeMean,3);
    lastEntry(~all(checkInt,3)) = meanAllSpec(~all(checkInt,3));
    % set parameters and set up for solver
    g0 = m.gCube(m.PiXCube);%*****???
    n0 = m.nCube(m.PiXCube);%*****???
    k0 = m.kCube(m.PiXCube);%*****???
    % now solve system of equations using simulation results as inital
    % guess...for now do it one at a time
    SS_approx = newInput;
    SS_approx(~all(checkInt,3)) = NaN;
    options = optimset('Display','off');
    lastEntry(isnan(lastEntry)) = 0;
    for eachCond = 1:max(size(SimProj.valueStimuli,1),size(SimProj.valueInhibitors,1))
        %only solve those that didn't converge
        if any(~all(checkInt(eachCond,:,:),3))
            inh0 = ones(1,size(m.specID,1));
            stim0 = ones(1,size(m.specID,1));
            % to simulate inhibition, we multiply the activation part of the equations by the
            % amount uninhibited
            if ~isempty(SimProj.valueInhibitors)
                inh0(SimProj.indexInhibitors) = SimProj.valueInhibitors(eachCond,:);
            end
            % to simulate stimulation, we make the derivative zero so it doesn't change and then
            % set the initial condition to stim value.
            if ~isempty(SimProj.valueStimuli)
                stim0(SimProj.indexStimuli(SimProj.valueStimuli(eachCond,:)>0)) = 0;
            else
                disp(' ')
                disp('Warning: simulation had no stimuli');
            end
            % make anonymous function.
            inputFun = eval(['@(y)' blanks(1) m.mFile(1:end-2) '(0,y,g0,n0,k0,inh0,stim0)']);
            % simulate
            SS_approx(eachCond,:) = fsolve(inputFun, lastEntry(eachCond,:), options);
        end
    end
    outputCompare(:,:,count+1) = SS_approx;
end
