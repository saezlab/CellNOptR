function QQLMWritePassingCombs(PassingCombs,SimProjExpt,Filename,varargin)
% Res = QQLMWritePassingCombs(PassingCombs,SimProject)
% Writes text file of Passing Combs (dimensions 1: environment, 2: expt
% condition, 3: model) based on SimProjExpt (Simulation with perturbation).
% Called by Q2LM in QQLMCompareToCriteria.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
%
% By Melody K. Morris for Q2LM software.  5/4/11

if nargin == 4
    onlySimple = varargin{1};
else
    onlySimple = false;
end

if size(PassingCombs,3) > 1
    ComputeFracModels = true;
else
    ComputeFracModels = false;
end

fid = fopen(fullfile('Results',Filename),'a');
if fid == -1
    fid = fopen(fullfile(Filename),'a');
end
for eachScen = 1:size(PassingCombs,1)
    if any(any(PassingCombs(eachScen,:,:)))
        Header = 'Scenario ';
        if ~isempty(SimProjExpt(eachScen).valueStimuli) && ...
                all(all(SimProjExpt(eachScen).valueStimuli == repmat(SimProjExpt(eachScen).valueStimuli(1,:),size(SimProjExpt(eachScen).valueStimuli,1),1)))
            Header = [Header 'Stimuli : '];
            namesHeader = SimProjExpt(eachScen).namesStimuli;
            valueHeader = SimProjExpt(eachScen).valueStimuli(1,:);
            namesSecondLine = SimProjExpt(eachScen).namesInhibitors;
            valuesBelow = SimProjExpt(eachScen).valueInhibitors;
        elseif ~isempty(SimProjExpt(eachScen).valueInhibitors) && ...
                all(all(SimProjExpt(eachScen).valueInhibitors == repmat(SimProjExpt(eachScen).valueInhibitors(1,:),size(SimProjExpt(eachScen).valueInhibitors,1),1)))
            Header = [Header 'Inhibitors : '];
            namesHeader = SimProjExpt(eachScen).namesInhibitors;
            valueHeader = SimProjExpt(eachScen).valueInhibitors(1,:);
            namesSecondLine = SimProjExpt(eachScen).namesStimuli;
            valuesBelow = SimProjExpt(eachScen).valueStimuli;
        elseif ~isempty(SimProjExpt(eachScen).valueStimuli)
            Header = [Header 'Stimuli : '];
            constants = all(SimProjExpt(eachScen).valueStimuli == repmat(SimProjExpt(eachScen).valueStimuli(1,:),size(SimProjExpt(eachScen).valueStimuli,1),1),1);
            namesHeader = SimProjExpt(eachScen).namesStimuli(constants);
            valueHeader = SimProjExpt(eachScen).valueStimuli(1,constants);
            namesSecondLine = SimProjExpt(eachScen).namesStimuli(~constants);
            valuesBelow = SimProjExpt(eachScen).valueStimuli(:,~constants);
        elseif ~isempty(SimProjExpt(eachScen).valueInhibitors)
            Header = [Header 'Inhibitors : '];
            constants = all(SimProjExpt(eachScen).valueInhibitors == repmat(SimProjExpt(eachScen).valueInhibitors(1,:),size(SimProjExpt(eachScen).valueInhibitors,1),1),1);
            namesHeader = SimProjExpt(eachScen).namesInhibitors(constants);
            valueHeader = SimProjExpt(eachScen).valueInhibitors(1,constants);
            namesSecondLine = SimProjExpt(eachScen).namesInhibitors(~constants);
            valuesBelow = SimProjExpt(eachScen).valueInhibitors(:,~constants);
        else
            disp('i cannot figure out what to output in file :-(')
        end
        for i = 1:numel(namesHeader)
            Header = strcat(Header,namesHeader{i},' = ',num2str(valueHeader(i)),',');
        end
        fprintf(fid,'%s\n','****************************');
        fprintf(fid,'%s\n',Header);
        strSecondLine = namesSecondLine;
        SecondLine = [];
        formatID =[];
        for j = 1:numel(namesSecondLine)
            SecondLine = [SecondLine '%s \t'];
            formatID = [formatID '%6.2f \t'];
        end
        if ComputeFracModels
            strSecondLine{end+1} = 'FractionModels';
            SecondLine = [SecondLine '%s \n'];
        else
            SecondLine = [SecondLine ' \n'];
        end
        if ComputeFracModels
            formatID = [formatID '%6.2f \n'];
        else
            formatID = [formatID ' \n'];
        end
        fprintf(fid,SecondLine,strSecondLine{:});
        totNumModels = size(PassingCombs,3);
        if onlySimple
            saveCond = zeros(1,size(valuesBelow,2));
        end
        for eachCond = 1:size(valuesBelow,1)
            if any(PassingCombs(eachScen,eachCond,:))
                if onlySimple
                    if ~any(any(saveCond==repmat(valuesBelow(eachCond,:),size(saveCond,1),1) & saveCond ~= 0))
                        if ComputeFracModels
                            fprintf(fid,formatID,[valuesBelow(eachCond,:) nnz(PassingCombs(eachScen,eachCond,:))/totNumModels]);
                        else
                            fprintf(fid,formatID,valuesBelow(eachCond,:));
                        end
                        saveCond = cat(1,saveCond,valuesBelow(eachCond,:));
                    end
                else
                    if ComputeFracModels
                        fprintf(fid,formatID,[valuesBelow(eachCond,:) nnz(PassingCombs(eachScen,eachCond,:))/totNumModels]);
                    else
                        fprintf(fid,formatID,valuesBelow(eachCond,:));
                    end
                end
            end
        end
    end
end
fclose(fid);