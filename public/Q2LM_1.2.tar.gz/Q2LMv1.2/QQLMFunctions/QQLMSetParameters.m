function Parameters =  QQLMSetParameters(ParametersIn)
% Parameters =  QQLMSetParameters(ParametersIn) sets Parameters as defaults
% and then overwrites them if ParametersIn has that one in it.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

CurrTimeSt=regexprep(regexprep(regexprep(regexprep(datestr(now),'-20',''),' ',''),':',''),'-','');
% set default parameters
Parameters = struct('Simulation',struct('ModelType','cFL','SimEngine',@QQLMSimEngCFL,'EndPoint','SteadyStateAvg',...
    'SimEngSpecific',struct('tfun',@CNOhillNonNorm,'Tolerance',0.0001,'MultSpecToSS',5,'FracSpecToSS',0.5)),...
    'SimProjCrit','No Criteria Provided',...
    'Filename',['ScenarioRes' CurrTimeSt]);

% initialize for what to look for in ParametersIn
FieldNames = cell(3,1);
currField = 1;
FieldNames{currField} = 'Simulation'; currField = currField+1;
FieldNames{currField} = 'SimProjCrit'; currField = currField+1;
FieldNames{currField} = 'Filename';
% if ParametersIn contains that parameter, overwrite default
for i = 1:currField
    if isfield(ParametersIn,FieldNames{i})
        eval(['Parameters.' FieldNames{i} '= ParametersIn.' FieldNames{i} ';']);
    end
end
     


