function QQLMCompareModelProjNames(m,SimProject)
% QQLMCompareModelProjNames(m,SimProject) returns an error if the species
% in SimProject don't have a corresponding name in m.specID.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

for iModel = 1:numel(m)
    mNames = cellstr(m(iModel).specID);
    % for each SimProject
    for iSimProj = 1:numel(SimProject)
        % check Stimuli names
        if ~isempty(SimProject(iSimProj).namesStimuli)
            for i = 1:numel(SimProject(iSimProj).namesStimuli)
                if ~any(strcmpi(SimProject(iSimProj).namesStimuli{i},mNames))
                    error(['Stimuli name *' SimProject(iSimProj).namesStimuli{i} '* does not have a corresponding model name'])
                end
            end
        end
        % Check inhibitor names
        if ~isempty(SimProject(iSimProj).namesInhibitors)
            for i = 1:numel(SimProject(iSimProj).namesInhibitors)
                if ~any(strcmpi(SimProject(iSimProj).namesInhibitors{i},mNames))
                    error(['Inhibitor name *' SimProject(iSimProj).namesInhibitors{i} '* does not have a corresponding model name'])
                end
            end
        end
    end
end