function outputMat = QQLMfullfact(vec)
%   outputMat = QQLMfullfact(vec) is the QQLM implementation of MatLabs
%   fullfact function (part of the statistics toolbox).
%   It creates a matrix DESIGN containing the
%    factor settings for a full factorial design. The vector vec
%    specifies the number of unique settings in each column of the design.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

lvec = length(vec);
totRow = prod(vec);

if lvec == 0 || totRow <= 0 || totRow ~= round(totRow)
    error('either no input vector or all entries were not positive integers')
end

outputMat = nan(totRow,lvec);

for i = 1:lvec-1
    toRep = [];
    currVec = 1:vec(i);
    for k = 1:vec(i)
        toRep = cat(1,toRep,repmat(currVec(k),prod(vec(i+1:end)),1));
    end
    toRep = repmat(toRep,prod(vec(1:i-1)),1);
    outputMat(:,i) = toRep;
end

outputMat(:,end) = repmat([1:vec(end)]',prod(vec(1:end-1)),1);