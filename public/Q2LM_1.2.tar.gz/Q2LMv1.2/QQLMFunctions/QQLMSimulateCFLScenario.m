function AllResults = QQLMSimulateCFLScenario(m,Scenario,Parameters)
% AllResults = QQLMSimulateCFLScenario(m,Scenario,Parameters)
% Takes a previously imported SimProject or pointer to Scenario file and
% simulates previously imported model (m) or pointer to model file with
% cFL.
% Parameters are also required (in the main QQLM Parameter structure, these
% are Parameters.Simulation).  Results are output into a 5-D array where
% the dimensions are as followes:
% Output dimension 1: Environments in Scenario
% Output dimension 2: Conditions in Scenario
% Output dimension 3: Species in Model (m)
% Output dimension 4: Time from simulation (maximum number of points stored
%       set by  Parameters.MaxTimeKept)
% Output dimension 5: Sinulated for each transfer function Parameter set
%       in Model (m)
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

% load model
if isstruct(m)
    Model = m;
elseif ischar(m)
    Model = QQLMLoadcFLModelMultiParams(m);
else
    error('undefined model input type')
end

% import scenario if applicable
if isstruct(Scenario)
    SimProject = Scenario;
elseif ischar(Scenario)
    SimProject = ImportScenario(Scenario);
else
    error('undefined scenario input type')
end

% warn if something will be implicitly ignored by simulation
specWithNoIn =  find(~any(Model.interMat==1,2));
for eachSpec = 1:length(specWithNoIn)
    if ~any(strcmpi(cellstr(Model.specID(specWithNoIn(eachSpec),:)),SimProject(1).namesStimuli))
        disp(' ')
        disp(['Model species ' Model.specID(specWithNoIn(eachSpec),:) ' has no input and is not set in SimProject.',...
            ' It will be a NaN and ignored in cFL simulation'])
    end
end

SimResultsTest = cell(numel(SimProject),size(Model.kMat,1));
allSizeCell = ones(numel(SimProject),size(Model.kMat,1));
% for each environment
count = 0;
countAll = 0;
timeCFL = tic;
disp(' ')            
for eachScen = 1:numel(SimProject)
    currSimProject = SimProject(eachScen);
    currSimProject.namesSignals = cellstr(Model(1).specID);
    % pre-process inhibitors at this point
    currSimProject.valueInhibitors = 1-currSimProject.valueInhibitors;
    % set obsolete field defaults in case engine is old version
    currSimProject.timeCues = 0;
    currSimProject.timeSignals = [0; 1];
    currSimProject.valueSignals=zeros(size(currSimProject.valueStimuli,1),numel(currSimProject.namesSignals));
    % set indexStimuli to index between scenario and model species
    currSimProject.indexStimuli = nan(1,numel(currSimProject.namesStimuli));
    for i = 1:numel(currSimProject.namesStimuli)
        currSimProject.indexStimuli(i) = find(strcmpi(currSimProject.namesStimuli{i},cellstr(Model(1).specID)));
    end
    % set indexInhibitors to index between scenario and model species
    currSimProject.indexInhibitors = nan(1,numel(currSimProject.namesInhibitors));
    for i = 1:numel(currSimProject.namesInhibitors)
        currSimProject.indexInhibitors(i) = find(strcmpi(currSimProject.namesInhibitors{i},cellstr(Model(1).specID)));
    end
    % for each model
    for eachModel = 1:size(Model.kMat,1)
        currM = Model;
        % simulate only one model at a time.
        currM.gCube(m.PiXCube) = currM.gMat(eachModel,m.PiX);
        currM.nCube(m.PiXCube) = currM.nMat(eachModel,m.PiX);
        currM.kCube(m.PiXCube) = currM.kMat(eachModel,m.PiX);
        % cFL can simulate all experimental conditions together as one big block.
        currSimRes = Parameters.SimEngine(currM,currSimProject,Parameters.SimEngSpecific);
        % only keep as much as you want or have memory for
        if size(currSimRes,3) > Parameters.MaxTimeKept
            SimResultsTest{eachScen,eachModel} = currSimRes(:,:,end-(Parameters.MaxTimeKept-1):end);
            allSizeCell(eachScen,eachModel) = Parameters.MaxTimeKept;
        else
            SimResultsTest{eachScen,eachModel} = currSimRes;
            allSizeCell(eachScen,eachModel) = size(currSimRes,3);
        end
        count = count + 1;
        countAll = countAll + 1;
        if toc(timeCFL) > 15
            disp(['On average, each of the last ' num2str(count) ' simulation blocks took ' num2str(toc(timeCFL)/count) ' seconds; ' num2str(countAll) ' simulation blocks complete.'])
            timeCFL = tic;
            count = 0;
        end
    end
end
% restructure SimResultsTest into AllResults matrix
AllResults = nan(numel(SimProject),size(SimResultsTest{1,1},1),size(SimResultsTest{1,1},2),max(max(allSizeCell)),size(Model.kMat,1));
for eachScen = 1:numel(SimProject)
    for eachModel = 1:size(Model.kMat,1)
        AllResults(eachScen,:,:,1:allSizeCell(eachScen,eachModel),eachModel) = SimResultsTest{eachScen,eachModel};
    end
end
