function Res = QQLMSimulateFullScenario(Model,Scenario,Parameters,varargin)
% Res = QQLMSimulateFullScenario(Model,Scenario,Parameters)
%   Simulates the environment and experimental conditions specified by
%   Scenario (either as structure of one previously loaded by QQLM or
%   a text file to be loaded in this function) with Model (again, either
%   a structure of one prev loaded or a text file to be loaded) using CFL
%   or logic-based ODEs as defined by Parameters (either a struct prev
%   loaded or text file to be loaded here).
%
% Res = QQLMSimulateFullScenario(Model,Scenario,Parameters,Criteria)
%   Same as above but it also takes in a Criteria and compares it
%   to the experiments in Scenario.  Criteria can be either a text file or
%   prev loaded structure, but it has to be the same type (structure or
%   text file) as Scenario.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

disp(' ')
disp('********************')
disp('QQLM Full Simulation')

% import scenario if applicable
disp(' ')
disp('Loading Scenario')
if isstruct(Scenario)
    SimProjExpt = Scenario;
    if nargin == 4
        if isstruct(varargin{1})
            SimProjCrit = varargin{1};
        else
            error('both scenario and criteria must be the same type: filenames or structures')
        end
    else
        SimProjCrit = 'No Criteria Provided';
    end
elseif ischar(Scenario)
    if nargin ==4
        CriteriaName = varargin{1};
        [SimProjExpt SimProjCrit] = QQLMImportScenario(Scenario,CriteriaName);
    else
        [SimProjExpt SimProjCrit] = QQLMImportScenario(Scenario);
    end
else
    error('undefined scenario input type')
end

% process parameters
disp(' ')
disp('Loading Parameters')
if isstruct(Parameters)
    Parameters = QQLMSetParameters(Parameters);
elseif ischar(Parameters)
    Parameters = QQLMLoadParameters(Parameters);
    Parameters = QQLMSetParameters(Parameters);
end


% load model
disp(' ')
disp('Loading Model')
if isstruct(Model)
    m = Model;
elseif ischar(Model)
    m = QQLMLoadModel(Model);
else
    error('undefined model input type')
end

% check SimProjCrit for consistency
if isstruct(Parameters.SimProjCrit) && ischar(SimProjCrit)
    SimProjCrit = Parameters.SimProjCrit;
elseif isstruct(Parameters.SimProjCrit) && isstruct(SimProjCrit)
    disp(' ')
    disp('Warning: SimProjCrit provided as parameter and in text file.  The one loaded from the text file will be used')
end

% check SimProjects and Model for naming consistency
QQLMCompareModelProjNames(m,SimProjExpt);
if ~ischar(SimProjCrit) && ~strcmpi(SimProjCrit(1).typeCrit,'NoFixScen')
    QQLMCompareModelProjNames(m,SimProjCrit);
    disp(' ')
    disp('Model/Scenario names checked out!')
end

% check for likely memory limitations
numSim = size(m.kMat,1)*numel(SimProjExpt);
numRes = numSim*max(size(SimProjExpt(1).valueStimuli,1),size(SimProjExpt(1).valueInhibitors,1))*size(m.specID,1);
if 2^24/numRes < 1
    error(['Too many Environments/Conditions/Models for one run. (Estimated at ' num2str(numRes) ') Break into pieces'])
elseif 2^24/numRes < Parameters.Simulation.MaxTimeKept
    disp(' ')
    disp(['Warning: With so many conditions, cannot keep as many time points as Parameters.Simulation.MaxTimeKept.  Instead, will save ' num2str(floor(2^24/numRes))])
    Parameters.Simulation.MaxTimeKept = floor(2^24/numRes);
end
% simulate first scenario
if strcmpi(Parameters.Simulation.ModelType,'cFL')
    EstTime = Parameters.Simulation.SimEngSpecific.MultSpecToSS*size(m.specID,1);
    disp(' ')
    disp([num2str(numSim) ' Simulation blocks will be performed.  At 0.001 sec/block, this is ' num2str(numSim*0.001/3600) ' hours but if the simulations oscillate, could be more like ' num2str(numSim*0.001*EstTime/3600) ' hours (at ' num2str(0.001*EstTime) ' sec/block)']);
    SimResExpt = QQLMSimulateCFLScenario(m,SimProjExpt,Parameters.Simulation);
elseif any(regexpi(Parameters.Simulation.ModelType,'ODE'))
    disp(' ')
    numSimWithCond = numSim*max(size(SimProjExpt(1).valueStimuli,1),size(SimProjExpt(1).valueInhibitors,1));
    disp([num2str(numSimWithCond) ' Individual ODE simulations will be performed.  At 0.01 sec/sim, this is ' num2str(numSimWithCond*0.01/3600) ' hours']);
    if ~strcmpi(char(Parameters.Simulation.SimEngine),'fsolve')
        SimResExpt = QQLMSimulateODEScenario(m,SimProjExpt,Parameters.Simulation);
    else
        SimResExpt = QQLMSimulateSSODEScenario(m,SimProjExpt,Parameters.Simulation);
    end
else
    error('Model type not recognized')
end

disp(' ')
disp('Done Simulating Scenario')

% compare to the criteria if applicable
if ~ischar(SimProjCrit)
    disp(' ')
    disp('Comparing to Criteria')
    Res = QQLMCompareToCriteria(SimResExpt,SimProjExpt,SimProjCrit,m,Parameters);
    disp(' ')
    disp('Full Simulation and Comparison Complete!')
    %otherwise, just output simulation results
else
    disp(' ')
    disp('No Criteria Found')
    
    Res = struct('Model',m,'SimProjExpt',SimProjExpt,'SimResExpt',SimResExpt,'Parameters',Parameters);
    CurrTimeSt=regexprep(regexprep(regexprep(regexprep(datestr(now),'-20',''),' ',''),':',''),'-','');
    try
        save(fullfile('Results',strcat(Parameters.Filename,CurrTimeSt)),'Res')
    catch
        disp(' ')
        disp('Could not find Results folder.  Will save in current directory')
        save(strcat(Parameters.Filename,CurrTimeSt),'Res')
    end
    disp(' ')
    disp('Full Simulation Complete!')
    %     disp(' ')
    %     Save=input('Would you like to plot the time courses? (y/n) ','s');
    %     if strcmp(Save,'y')
    %         QQLMPlotAllTimeCourse(m,SimResExpt)
    %     end
end


