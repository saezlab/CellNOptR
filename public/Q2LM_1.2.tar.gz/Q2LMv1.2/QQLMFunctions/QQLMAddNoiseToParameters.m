function mRand = QQLMAddNoiseToParameters(m,sigma,n,OnlyInvariant)
% m = QQLMAddNoiseToParameters(m,sigma,n,OnlyInvariant)
%   for each model (m), makes n models with noise added to parameters
%   (noise level is randomly chosen from normal distribution with variance
%   sigma).  If OnlyInvariant is true, only parameters that are the same
%   across all models have noise added.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

nInit = size(m.kMat,1);

% check how many models will be made
if n*nInit>1000
    disp(' ')
    disp('Warning: more than 1000 model sets will be generated')
end

% determine if the parameters are always the same if OnlyInvariant Option
% is chosen.
if OnlyInvariant
    DoNotChange = any(m.kMat ~= repmat(min(m.kMat,[],1),nInit,1),1) | any(m.nMat ~= repmat(min(m.nMat,[],1),nInit,1),1) | any(m.gMat ~= repmat(min(m.gMat,[],1),nInit,1),1);
else
    DoNotChange = false(size(m.kMat,2),1);
end

% initialize
mRand = m;
mRand.kMat = 0.5*ones(nInit*n,size(m.kMat,2));
mRand.nMat = 3*ones(nInit*n,size(m.nMat,2));
mRand.gMat = ones(nInit*n,size(m.gMat,2));

for eachIter = 1:n
    % make random numbers
    kRand = randn(size(m.kMat));
    nRand = randn(size(m.nMat));
    gRand = randn(size(m.gMat));
    % add to parameters
    mRand.kMat((eachIter-1)*nInit+1:eachIter*nInit,:) = m.kMat.*(1+sigma.*kRand);
    mRand.nMat((eachIter-1)*nInit+1:eachIter*nInit,:) = m.nMat.*(1+sigma.*nRand);
    mRand.gMat((eachIter-1)*nInit+1:eachIter*nInit,:) = m.gMat.*(1+sigma.*gRand);
    % overwrite with former value for those that weren't supposed to
    % change.
    mRand.kMat((eachIter-1)*nInit+1:eachIter*nInit,DoNotChange) = m.kMat(:,DoNotChange);
    mRand.nMat((eachIter-1)*nInit+1:eachIter*nInit,DoNotChange) = m.nMat(:,DoNotChange);
    mRand.gMat((eachIter-1)*nInit+1:eachIter*nInit,DoNotChange) = m.gMat(:,DoNotChange);
end

mRand.gMat(mRand.gMat > 1) = 1;

