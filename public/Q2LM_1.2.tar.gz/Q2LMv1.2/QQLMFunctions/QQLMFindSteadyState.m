function lastEntry = QQLMFindSteadyState(outputCompare,varargin)
% lastEntry = QQLMFindSteadyState(outputCompare) returns an 
%   n x m x 1 matrix of steady state values from the n x m x t simulation 
%   result stored in outputCompare.  n is number of conditions, m is number
%   of species, t is number of timepoints. If any species in any condition
%   has not reached steady state as defined by the Tolerance, 
%   the function goes back a number of steps (equal toFracSpecToSS times 
%   numSpecies in model) and assigns a NaN to any species that changed 
%   within that number of steps.  This is very conservative, since some 
%   might have actually stabilized if the number of steps is a lot compared 
%   to the total simulation time. Defaults are used as Tolerance and 
%   FracSpecToSS. 
%
% lastEntry = QQLMFindSteadyState(outputCompare,Parameters) is the same 
%   except Tolerance and FracSpecToSS are set by Parameters 
%   (Parameters.SimEngSpec in QQLM format). 
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
%
% By Melody K. Morris for Q2LM software.  5/4/11

numExpt = size(outputCompare,1);
numSpecies = size(outputCompare,2);

if nargin==2 && ~isempty(varargin{1})
    testMat = varargin{1}.Tolerance*ones(numExpt, numSpecies);
    fracSpecToSS = varargin{1}.FracSpecToSS;
else
    testMat=1E-3*ones(numExpt, numSpecies);
    fracSpecToSS = 0.5;
end

newInput = outputCompare(:,:,end);
newInputComp = newInput;
outputPrev = outputCompare(:,:,end-1);
newInputComp(isnan(newInput)) = 0;
outputPrev(isnan(outputPrev)) = 0;
    
lastEntry = newInput;
%compute final output
if ~all(all(abs((outputPrev-newInputComp))<testMat))
    % go back many steps to look for stability
    checkInt = false(size(outputCompare,1),size(outputCompare,2),ceil(numSpecies*fracSpecToSS)+1);
    ixend = size(outputCompare,3);
    % store if it was the same at that point
    for i = 0:ceil(numSpecies*fracSpecToSS)
        ix1 = ixend - i;
        ix2 = ixend - (i+1);
        checkInt(:,:,i+1) = abs((outputCompare(:,:,ix1)-outputCompare(:,:,ix2)))<testMat;
    end
    % if any have changed, it might not have stabilized and is thus
    % replaced with a nan.
    lastEntry(~all(checkInt,3)) = nan;
end