function Res = QQLMCompareToCriteria(SimResExpt,SimProjExpt,SimProjCrit,Model,Parameters)
% Res =
% QQLMCompareToCriteria(SimResExpt,SimProjExpt,SimProjCrit,Model,Parameters)
%
% Compares SimResExpt previously simulated based on SimProjExpt and Model
% to comparisom scenario in SimProjCrit.  Main Parameters of Q2LM required.
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

% Take endpoint of SimResExpt if applicable
if any(regexpi(SimProjCrit(1).EndPoint,'SteadyState'))
    SimResExptComp = QQLMMakeRepTimeVal(SimResExpt,SimProjCrit,Parameters.Simulation);
elseif strcmpi(SimProjCrit(1).EndPoint,'FinalVal')
    SimResExptComp = nan(size(SimResExpt,1),size(SimResExpt,2),size(SimResExpt,3),size(SimResExpt,5));
    for eachScen = 1:size(SimResExpt,1)
        for eachModel = 1:size(SimResExpt,5)
            % have to do ignore the nans that are filler at the end
            endTimeIx = max(sum(~isnan(squeeze(SimResExpt(eachScen,1,:,:,eachModel))),2));
            SimResExptComp(eachScen,:,:,eachModel) = permute(SimResExpt(eachScen,:,:,endTimeIx,eachModel),[2 3 4 1 5]);
        end
    end
elseif strcmpi(SimProjCrit(1).EndPoint,'Max')
    saveNaNs = all(SimResExpt == repmat(max(SimResExpt,[],4),[1 1 1 size(SimResExpt,4) 1]),4);
    SimResExptComp = max(SimResExpt,[],4);
    SimResExptComp(saveNaNs) = NaN;
    disp(' ')
    disp(['max of ' num2str(nnz(saveNaNs)) ' expt points could not be reliably calculated because it was always the same value.  They were recorded as NaNs.    If this should not have been the case, it might have been that oscillations in other simulations caused a recording problem'])
elseif strcmpi(SimProjCrit(1).EndPoint,'DecayTime')
    SimResExptComp = QQLMCalculateDecayTime(SimResExpt,Parameters.Simulation);
else
    error('Unrecognized CritProj EndPoint')
end


% find the relevant Signal(s)
SignalCrit = nan(numel(SimProjCrit(1).specChange),1);
for eachSigCrit = 1:numel(SimProjCrit(1).specChange)
    if strcmpi(SimProjCrit(1).typeCrit,'NoFixScen') && ~(any(regexpi(SimProjCrit(1).mathChange{eachSigCrit},'abs')) && any(regexpi(SimProjCrit(1).mathChange{eachSigCrit},'value')))
        error('When the comparison scenario is not specified, all change criteria must be absolute number, not changes.')
    end
    if nnz(strcmpi(SimProjCrit(1).specChange{eachSigCrit},cellstr(Model(1).specID)))==1
        SignalCrit(eachSigCrit) = find(strcmpi(SimProjCrit(1).specChange{eachSigCrit},cellstr(Model(1).specID)));
    end
end
if any(isnan(SignalCrit))
    disp(['could not find criteria signal' SimProjCrit(1).specChange{isnan(SignalCrit)} ' or double species are in model'])
    SignalCrit(isnan(SignalCrit)) = [];
end
relevResExpt = SimResExptComp(:,:,SignalCrit,:);

% simulate criteria and copy results to match experiment
if ~strcmpi(SimProjCrit(1).typeCrit,'NoFixScen')
    if strcmpi(SimProjCrit(1).typeCrit,'Model')
        disp(' ')
        disp('Loading model for comparison')
        ModelComp = QQLMLoadModel(SimProjCrit(1).ModelName);
    else
        ModelComp = Model;
    end
    if strcmpi(Parameters.Simulation.ModelType,'cFL')
        SimResCrit = QQLMSimulateCFLScenario(ModelComp,SimProjCrit,Parameters.Simulation);
    elseif any(regexpi(Parameters.Simulation.ModelType,'ODE'))
        if ~strcmpi(char(Parameters.Simulation.SimEngine),'fsolve')
            SimResCrit = QQLMSimulateODEScenario(ModelComp,SimProjCrit,Parameters.Simulation);
        else
            SimResCrit = QQLMSimulateSSODEScenario(ModelComp,SimProjCrit,Parameters.Simulation);
        end
    end
    if any(regexpi(SimProjCrit(1).EndPoint,'SteadyState'))
        SimResComp = QQLMMakeRepTimeVal(SimResCrit,SimProjCrit,Parameters.Simulation);
    elseif strcmpi(SimProjCrit(1).EndPoint,'FinalVal')
        SimResComp = nan(size(SimResCrit,1),size(SimResCrit,2),size(SimResCrit,3),size(SimResCrit,5));
        for eachScen = 1:size(SimResCrit,1)
            for eachModel = 1:size(SimResCrit,5)
                % have to do ignore the nans that are filler at the end
                endTimeIx = max(sum(~isnan(squeeze(SimResCrit(eachScen,1,:,:,eachModel))),2));
                SimResComp(eachScen,:,:,eachModel) = permute(SimResCrit(eachScen,:,:,endTimeIx,eachModel),[2 3 4 1 5]);
            end
        end
    elseif strcmpi(SimProjCrit(1).EndPoint,'Max')
        saveNaNs = all(SimResCrit == repmat(max(SimResCrit,[],4),[1 1 1 size(SimResCrit,4) 1]),4);
        SimResComp = max(SimResCrit,[],4);
        SimResComp(saveNaNs)= NaN;
        disp(' ')
        disp(['max of ' num2str(nnz(saveNaNs)) ' crit points could not be reliably calculated because it was always the same value.  They were recorded as NaNs.  If this should not have been the case, it might have been that oscillations in other simulations caused a recording problem'])
    elseif strcmpi(SimProjCrit(1).EndPoint,'DecayTime')
        SimResComp = QQLMCalculateDecayTime(SimResCrit,Parameters.Simulation);
    else
        error('Unrecognized CritProj EndPoint')
    end
    %Do this third so you don't simulate the same thing over and over
    SimResComp = QQLMMakeCritProjCompatible(SimResExpt,SimProjCrit,SimResComp);
    relevResCrit = SimResComp(:,:,SignalCrit,:);
else
    SimResComp = 'No Comparison Scenario Specied. This only makes sense if your criteria are all for absolute values';
    ModelComp = Model;
end
CritMat = zeros(size(relevResExpt));
singlePassCrit = false(size(relevResExpt));
for eachSigCrit = 1:length(SignalCrit)
    % do the math
    if any(regexpi(SimProjCrit(1).mathChange{eachSigCrit},'abs')) && any(regexpi(SimProjCrit(1).mathChange{eachSigCrit},'change'))
        CritMat(:,:,eachSigCrit,:) = relevResExpt(:,:,eachSigCrit,:) - relevResCrit(:,:,eachSigCrit,:);
    elseif any(regexpi(SimProjCrit(1).mathChange{eachSigCrit},'relat'))
        CritMat(:,:,eachSigCrit,:) = (relevResExpt(:,:,eachSigCrit,:) -relevResCrit(:,:,eachSigCrit,:))./relevResCrit(:,:,eachSigCrit,:);
    elseif any(regexpi(SimProjCrit(1).mathChange{eachSigCrit},'value'))
        CritMat(:,:,eachSigCrit,:) = relevResExpt(:,:,eachSigCrit,:);
    else
        error('undefined change math.  please specify absolute or relative')
    end
    if any(regexpi(SimProjCrit(1).mathChange{eachSigCrit},'replace')) && any(regexpi(SimProjCrit(1).mathChange{eachSigCrit},'inf'))
        CritMat(isinf(CritMat)) = NaN;
    end
    if ~any(regexpi(SimProjCrit(1).mathChange{eachSigCrit},'value'))
        if any(regexpi(SimProjCrit(1).signChange{eachSigCrit},'inc'))
            singlePassCrit(:,:,eachSigCrit,:) = CritMat(:,:,eachSigCrit,:) >= SimProjCrit(1).amountChange{eachSigCrit};
        elseif any(regexpi(SimProjCrit(1).signChange{eachSigCrit},'dec'))
            singlePassCrit(:,:,eachSigCrit,:) = CritMat(:,:,eachSigCrit,:) <= -1*SimProjCrit(1).amountChange{eachSigCrit};
        else
            error('undefined change sign.  please specify increase or decrease')
        end
    else
        if any(regexpi(SimProjCrit(1).signChange{eachSigCrit},'greater'))
            singlePassCrit(:,:,eachSigCrit,:) = CritMat(:,:,eachSigCrit,:) > SimProjCrit(1).amountChange{eachSigCrit};
        elseif any(regexpi(SimProjCrit(1).signChange{eachSigCrit},'less'))
            singlePassCrit(:,:,eachSigCrit,:) = CritMat(:,:,eachSigCrit,:) < SimProjCrit(1).amountChange{eachSigCrit};
        else
            error('undefined change sign.  please specify increase or decrease')
        end
    end
end
if strcmpi(SimProjCrit(1).numCritPass,'all')
    PassingCombs = all(singlePassCrit,3);
elseif strcmpi(SimProjCrit(1).numCritPass,'any')
    PassingCombs = any(singlePassCrit,3);
else
    error('Undefined number of criteria that must be true to pass.  Please specify all or any')
end
PassingCombs = reshape(PassingCombs,size(PassingCombs,1),size(PassingCombs,2),size(PassingCombs,4));

CurrTimeSt=regexprep(regexprep(regexprep(regexprep(datestr(now),'-20',''),' ',''),':',''),'-','');
% save results
Res = struct('Model',Model,'ModelComp',ModelComp,'SimProjExpt',SimProjExpt,'SimResExpt',SimResExpt,'SimResExptEnd',SimResExptComp,...
    'SimProjCrit',SimProjCrit,'SimResComp',SimResComp,'PassingCombs',PassingCombs,'CritMat',CritMat,'Parameters',Parameters);
try
    save(fullfile('Results',strcat(Parameters.Filename,CurrTimeSt)),'Res')
catch
    disp(' ')
    disp('Could not find Results folder.  Will save result in current directory')
    save(strcat(Parameters.Filename,CurrTimeSt),'Res')
end
% make printout of results
QQLMWritePassingCombs(PassingCombs,SimProjExpt,[Parameters.Filename CurrTimeSt]);
