function mFew = QQLMChooseModelsRandomly(m,Frac)
% mFew = QQLMTakeRandomModels(m,Frac)
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% Randomly chooses the specified fraction (Frac) of parameter sets from the
% Model m.  This comes in handy if a lot of parameter sets were explored

[dummy TakeIx] = sort(rand(size(m.kMat,1),1));
mFew = rmfield(m,'kMat','nMat','gMat');
mFew.gMat = m.gMat(TakeIx(ceil(size(m.gMat,1)*Frac)),:);
mFew.nMat = m.nMat(TakeIx(ceil(size(m.nMat,1)*Frac)),:);
mFew.kMat = m.kMat(TakeIx(ceil(size(m.kMat,1)*Frac)),:);
