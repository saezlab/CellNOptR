function SimResExptComp = QQLMCalculateDecayTime(SimResExpt,Parameters)
% SimResExptComp = QQLMCalculateDecayTime(SimResExpt,Parameters);
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
[numScen numCond numSpec numTime numModel] = size(SimResExpt);

SimResExptComp = nan(numScen,numCond,numSpec,numModel);

numInel = 0;

for eachScen = 1:numScen
    for eachModel = 1:numModel
        for eachCond = 1:numCond
            for eachSpec = 1:numSpec
                if all(SimResExpt(eachScen,eachCond,eachSpec,:,eachModel)== max(SimResExpt(eachScen,eachCond,eachSpec,:,eachModel)))
                    SimResExptComp(eachScen,eachCond,eachSpec,eachModel) = NaN;
                    numInel = numInel + 1;
                else
                    currMaxIX = find(SimResExpt(eachScen,eachCond,eachSpec,:,eachModel)== max(SimResExpt(eachScen,eachCond,eachSpec,:,eachModel)),1,'first');
                    if any(SimResExpt(eachScen,eachCond,eachSpec,currMaxIX:end,eachModel)<=0.01)
                        SimResExptComp(eachScen,eachCond,eachSpec,eachModel) = find(SimResExpt(eachScen,eachCond,eachSpec,currMaxIX:end,eachModel)<=0.01,1,'first')-1;
                    else
                        SimResExptComp(eachScen,eachCond,eachSpec,eachModel) = inf;
                    end
                end
            end
        end
    end
end
% if it was oscillating, make it a NaN
EndPointSS = QQLMMakeRepTimeVal(SimResExpt,struct('EndPoint','SteadyState'),Parameters);
SimResExptComp(isnan(EndPointSS)) = NaN;

disp(' ')
disp([num2str(nnz(isnan(EndPointSS))) ' points oscillated'])

if numInel > 0
    disp(' ')
    disp([num2str(numInel) ' points could not be calculated because it was always the same value.   They were recorded as NaNs.    If this should not have been the case, it might have been that oscillations in other simulations caused a recording problem'])
end