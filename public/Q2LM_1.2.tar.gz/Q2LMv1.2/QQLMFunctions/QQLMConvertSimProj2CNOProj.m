function CNOProject = QQLMConvertSimProj2CNOProj(SimProj,varargin)
% CNOProject = QQLMConvertSimProj2CNOProj(SimProj,varargin)
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%

CNOProject.namesStimuli = SimProj(1).namesStimuli;
CNOProject.namesInhibitors = SimProj(1).namesInhibitors;

CNOProject.valueStimuli = [];
CNOProject.valueInhibitors = [];
for i = 1:numel(SimProj)
    CNOProject.valueStimuli = cat(1,CNOProject.valueStimuli,SimProj(i).valueStimuli);
    CNOProject.valueInhibitors = cat(1,CNOProject.valueInhibitors,SimProj(i).valueInhibitors);
end
CNOProject.namesCues = cat(1,CNOProject.namesStimuli,CNOProject.namesInhibitors);
CNOProject.valueCues = cat(2,CNOProject.valueStimuli,CNOProject.valueInhibitors);
CNOProject.timeCues = 0;

if nargin > 1
    SimRes = varargin{1};
    Model = varargin{2};
    if size(SimRes,4) > 1
        disp('Warning: Multiple Time Steps are being saved')
    end
    if size(SimRes,5) > 1 && nargin < 4
        error('If multiple model results are in SimResExpt, please either specify an index or the string -Avg- as the fourth input')
    elseif size(SimRes,5) > 1
        if isnumeric(varargin{3})
            SimResUse = SimRes(:,:,:,:,varargin{3});
        elseif ischar(varargin{3}) && strcmpi('Avg',varargin{3})
            SimResUse = CNOnanmean(SimRes,5);
        else
            error('If multiple model results are in SimResExpt, please either specify and index or the string -Avg- as the fourth input')
        end
    else
        SimResUse = SimRes;
    end
    CNOProject.timeSignals = 1:size(SimResUse,4);
    CNOProject.namesSignals = cellstr(Model.specID);
    CNOProject.valueSignals = [];
    for i = 1:numel(SimProj)
        CNOProject.valueSignals = cat(1,CNOProject.valueSignals,permute(SimResUse(i,:,:,:),[2 3 4 1]));
    end
    CNOProject.DataCubeStruct = [];
    CNOProject.DataCubeNames = [];
end
