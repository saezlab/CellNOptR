function [SimProject SimProjCrit] = QQLMImportScenario(ScenID,varargin)
% [SimProject SimProjCrit] = QQLMImportScenario(filename)
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

fid = fopen(fullfile('Scenarios',ScenID));
if fid == -1
    fid = fopen(fullfile(ScenID));
    if fid == -1
        error('no scenario file found in the "Scenarios" folder or MatLab path')
    end
end
ReadFile =textscan(fid,'%q %q %q %f %f %q','delimiter','\t','CommentStyle','#');
fclose(fid);

ScenType = ReadFile{1};
%% No matter what, second column is fixed
ScenCond = ReadFile{2};
% clean up
EmptyScen = false(numel(ScenCond),1);
for i = 1:numel(ScenCond)
    EmptyScen(i) = isempty(ScenCond{i});
end
ScenCond(EmptyScen) = [];
% find names and values of scenarios
[Names1 Values1] = QQLMIDScenCond(ScenCond);

% figure out if you need to vary for the third column and make names/values
if any(regexpi(ScenType{2},'Vary'))
    Names2 = ReadFile{3};
    % clean up
    EmptyName = false(numel(Names2),1);
    for i = 1:numel(Names2)
        EmptyName(i) = isempty(Names2{i});
    end
    Names2(EmptyName) = [];
    % assign variables
    ValVary = ReadFile{4};
    ValVary(isnan(ValVary)) = [];
    
    MaxNum = ReadFile{5}(1);
    % make value combinations
    Values2 = QQLMMakeCondComb(Names2,ValVary,MaxNum);
elseif any(regexpi(ScenType{2},'Fix'))
    % clean up
    ScenCond2 = ReadFile{3};
    EmptyScen2 = false(numel(ScenCond2),1);
    for i = 1:numel(ScenCond2)
        EmptyScen2(i) = isempty(ScenCond2{i});
    end
    ScenCond2(EmptyScen2) = [];
    % find names/values
    [Names2 Values2] = QQLMIDScenCond(ScenCond2);
elseif isempty(ScenType{2})
    ScenType{2} = 'None';
else
    error(['I do not know what to do with experimental condition.  Is is supposed ',...
        ' to be a fixed scenario or varied?  Indicate in first column, second entry of text file'])
end

disp(' ')
disp([num2str(numel(Names1)) ' species make up ' num2str(size(Values1,1)) ' environments'])
if ~strcmpi(ScenType{2},'None')
    disp(['and ' num2str(numel(Names2)) ' species make up ' num2str(size(Values2,1)) ' experiments.'])
    % Check that there isn't any overlap between Environment and Experiment
    % species
    for eEnvSpec = numel(Names1):-1:1
        if any(strcmpi(Names1{eEnvSpec},Names2))
            disp(' ')
            disp(['Warning: Species *' Names1{eEnvSpec} '* supplied as both environment and experimental species.  Only the Experimental values will be used'])
            Names1(eEnvSpec) = [];
            Values1(:,eEnvSpec) = [];
        end
    end
    
end

% assemble depending on first column text file
if any(regexpi(ScenType{1},'Stim'))
    if any(regexpi(ScenType{2},'Stim'))
        disp(' ')
        disp(['I have detected that both the environment species and experimental species are Stimuli.  If that is ',...
            ' not correct, edit first column of text file'])
        for eachScen1 = 1:size(Values1,1)
            SimProject(eachScen1).namesStimuli = cat(1,Names1,Names2);
            SimProject(eachScen1).valueStimuli = cat(2,repmat(Values1(eachScen1,:),size(Values2,1),1),Values2);
            SimProject(eachScen1).namesInhibitors = {};
            SimProject(eachScen1).valueInhibitors = [];
        end
    elseif any(regexpi(ScenType{2},'Inhib'))
        disp(' ')
        disp(['I have detected that the environment species is a Stimuli and the experimental species is an Inhibitor. ',...
            ' If that is not correct, edit first column of text file'])
        for eachScen1 = 1:size(Values1,1)
            SimProject(eachScen1).namesStimuli = Names1;
            SimProject(eachScen1).valueStimuli = repmat(Values1(eachScen1,:),size(Values2,1),1);
            SimProject(eachScen1).namesInhibitors = Names2;
            SimProject(eachScen1).valueInhibitors = Values2;
        end
    elseif strcmpi(ScenType{2},'None')
        disp(' ')
        disp(['I have detected that the environment species is a Stimuli and there are no experimental species. ',...
            'If that is not correct, edit first column of text file'])
        for eachScen1 = 1:size(Values1,1)
            SimProject(eachScen1).namesStimuli = Names1;
            SimProject(eachScen1).valueStimuli = Values1(eachScen1,:);
            SimProject(eachScen1).namesInhibitors = {};
            SimProject(eachScen1).valueInhibitors = [];
        end
    else
        error(['I do not know what kind of the environmental and experimental species  you want.  Are they supposed ',...
            ' to be a Stimuli or Inhibitors?  Indicate in first column of text file'])
    end
elseif any(regexpi(ScenType{1},'Inhib'))
    if any(regexpi(ScenType{2},'Inhib'))
        disp(' ')
        disp(['I have detected that both both the environmental and experimental species are Inhibitors.  If that is ',...
            ' not correct, edit first column of text file'])
        for eachScen1 = 1:size(Values1,1)
            SimProject(eachScen1).namesInhibitors = cat(1,Names1,Names2);
            SimProject(eachScen1).valueInhibitors = cat(2,repmat(Values1(eachScen1,:),size(Values2,1),1),Values2);
            SimProject(eachScen1).namesStimuli = {};
            SimProject(eachScen1).valueStimuli = [];
        end
    elseif any(regexpi(ScenType{2},'Stim'))
        disp(' ')
        disp(['I have detected that the environmental species is an Inhibitor and the experimental species is a Stimuli. ',...
            ' If that is not correct, edit first column of text file'])
        for eachScen1 = 1:size(Values1,1)
            SimProject(eachScen1).namesInhibitors = Names1;
            SimProject(eachScen1).valueInhibitors = repmat(Values1(eachScen1,:),size(Values2,1),1);
            SimProject(eachScen1).namesStimuli = Names2;
            SimProject(eachScen1).valueStimuli = Values2;
        end
    elseif strcmpi(ScenType{2},'None')
        disp(' ')
        disp(['I have detected that the environment species is ann Inhibitor and there are no experimental species. ',...
            'If that is not correct, edit first column of text file'])
        for eachScen1 = 1:size(Values1,1)
            SimProject(eachScen1).namesInhibitors = Names1;
            SimProject(eachScen1).valueInhibitors = Values1(eachScen1,:);
            SimProject(eachScen1).namesStimuli = {};
            SimProject(eachScen1).valueStimuli = [];
        end
    else
        error(['I do not know what kind of environmental and experimental species you want.  Are they supposed ',...
            ' to be a Stimuli or Inhibitors?  Indicate in first column of text file'])
    end
else
    error(['I do not know what kind of environmental and experimental species you want.  Are they supposed ',...
        ' to be a Stimuli or Inhibitors?  Indicate in first column of text file'])
end

if nargin == 2
    filenameCrit = varargin{1};
    fid = fopen(fullfile('Criteria',filenameCrit));
    if fid == -1
        fid = fopen(fullfile(filenameCrit));
        if fid == -1
            error('no criteria file found in the "Criteria" folder or MatLab path')
        end
    end
    ReadFileCrit =textscan(fid,'%q %q','delimiter','\t','CommentStyle','#');
    
    Criteria = ReadFileCrit{2};
    specChange = QQLMGuessCueNames({Criteria{1}});
    numCritPass = Criteria{2};
    mathChange = QQLMGuessCueNames({Criteria{3}});
    if numel(mathChange)==1 && (numel(mathChange) ~= numel(specChange))
        mathChangeTemp = cell(numel(specChange),1);
        for eachMath = 1:numel(specChange)
            mathChangeTemp{eachMath} = mathChange{1};
        end
        mathChange = mathChangeTemp;
    elseif (numel(mathChange) ~= numel(specChange))
        error('number of criteria species and math operations does not match')
    end
    signChange = QQLMGuessCueNames({Criteria{4}});
    if numel(signChange)==1 && (numel(signChange) ~= numel(specChange))
        signChangeTemp = cell(numel(specChange),1);
        for eachMath = 1:numel(specChange)
            signChangeTemp{eachMath} = signChange{1};
        end
        signChange = signChangeTemp;
    elseif (numel(mathChange) ~= numel(specChange))
        error('number of criteria species and sign operations does not match')
    end
    allAmounts = QQLMGuessCueNames({Criteria{5}});
    amountChange = cellfun(@eval,allAmounts,'UniformOutput',false);
    if length(amountChange) ==1 && (length(amountChange) ~= numel(specChange))
        amountChange = repmat(amountChange,numel(specChange),1);
    elseif (numel(mathChange) ~= numel(specChange))
        error('number of criteria species and change values does not match')
    end
    EndPoint = Criteria{7};
    if any(regexpi(Criteria{6},'all')) && any(regexpi(Criteria{6},'fix'))
        typeCrit = 'AllFixScen';
        if any(regexpi(ScenType{1},'Stim'))
            if any(regexpi(ScenType{2},'Stim'))
                for eachScen1 = 1:size(Values1,1)
                    SimProjCrit(eachScen1).namesStimuli = cat(1,Names1,Names2);
                    SimProjCrit(eachScen1).valueStimuli = cat(2,Values1(eachScen1,:),zeros(1,size(Values2,2)));
                    SimProjCrit(eachScen1).namesInhibitors = {};
                    SimProjCrit(eachScen1).valueInhibitors = [];
                end
            elseif any(regexpi(ScenType{2},'Inhib'))
                for eachScen1 = 1:size(Values1,1)
                    SimProjCrit(eachScen1).namesStimuli = Names1;
                    SimProjCrit(eachScen1).valueStimuli = Values1(eachScen1,:);
                    SimProjCrit(eachScen1).namesInhibitors = Names2;
                    SimProjCrit(eachScen1).valueInhibitors = zeros(1,size(Values2,2));
                end
            elseif strcmpi(ScenType{2},'None')
                for eachScen1 = 1:size(Values1,1)
                    SimProjCrit(eachScen1).namesStimuli = Names1;
                    SimProjCrit(eachScen1).valueStimuli = Values1(eachScen1,:);
                    SimProjCrit(eachScen1).namesInhibitors = {};
                    SimProjCrit(eachScen1).valueInhibitors = [];
                end
            else
                error(['I do not know what kind of the environmental and experimental species  you want.  Are they supposed ',...
                    ' to be a Stimuli or Inhibitors?  Indicate in first column of text file'])
            end
            for eachCond = 1:size(Values1,1)
                SimProjCrit(eachCond).typeCrit = typeCrit;
                SimProjCrit(eachCond).specChange = specChange;
                SimProjCrit(eachCond).numCritPass = numCritPass;
                SimProjCrit(eachCond).mathChange = mathChange;
                SimProjCrit(eachCond).signChange = signChange;
                SimProjCrit(eachCond).amountChange = amountChange;
                SimProjCrit(eachCond).EndPoint = EndPoint;
            end
        elseif any(regexpi(ScenType{1},'Inhib'))
            if any(regexpi(ScenType{2},'Inhib'))
                for eachScen1 = 1:size(Values1,1)
                    SimProjCrit(eachScen1).namesInhibitors = cat(1,Names1,Names2);
                    SimProjCrit(eachScen1).valueInhibitors = cat(2,Values1(eachScen1,:),zeros(1,size(Values2,2)));
                    SimProjCrit(eachScen1).namesStimuli = {};
                    SimProjCrit(eachScen1).valueStimuli = [];
                end
            elseif any(regexpi(ScenType{2},'Stim'))
                for eachScen1 = 1:size(Values1,1)
                    SimProjCrit(eachScen1).namesInhibitors = Names1;
                    SimProjCrit(eachScen1).valueInhibitors = Values1(eachScen1,:);
                    SimProjCrit(eachScen1).namesStimuli = Names2;
                    SimProjCrit(eachScen1).valueStimuli = zeros(1,size(Values2,2));
                end
            elseif strcmpi(ScenType{2},'None')
                for eachScen1 = 1:size(Values1,1)
                    SimProjCrit(eachScen1).namesInhibitors = Names1;
                    SimProjCrit(eachScen1).valueInhibitors = Values1(eachScen1,:);
                    SimProjCrit(eachScen1).namesStimuli = {};
                    SimProjCrit(eachScen1).valueStimuli = [];
                end
            else
                error(['I do not know what kind of environmental and experimental species you want.  Are they supposed ',...
                    ' to be a Stimuli or Inhibitors?  Indicate in first column of text file'])
            end
            for eachCond = 1:size(ValuesCrit,1)
                SimProjCrit(eachCond).namesInhibitors = SimProject(eachCond).namesInhibitors;
                SimProjCrit(eachCond).valueInhibitors = SimProject(eachCond).valueInhibitors(1,:);
                SimProjCrit(eachCond).namesStimuli = {};
                SimProjCrit(eachCond).valueStimuli = [];
                SimProjCrit(eachCond).typeCrit = typeCrit;
                SimProjCrit(eachCond).specChange = specChange;
                SimProjCrit(eachCond).numCritPass = numCritPass;
                SimProjCrit(eachCond).mathChange = mathChange;
                SimProjCrit(eachCond).signChange = signChange;
                SimProjCrit(eachCond).amountChange = amountChange;
                SimProjCrit(eachCond).EndPoint = EndPoint;
            end
        else
            error('could not identify if criteria condition was stim or inhib')
        end
    elseif any(regexpi(Criteria{6},'='))
        [NamesCrit ValuesCrit] = QQLMIDScenCond(Criteria(6));
        typeCrit = 'SingleFixScen';
        if any(regexpi(ScenType{1},'Stim'))
            for eachCond = 1:size(ValuesCrit,1)
                SimProjCrit(eachCond).namesStimuli = NamesCrit;
                SimProjCrit(eachCond).valueStimuli = ValuesCrit;
                SimProjCrit(eachCond).namesInhibitors = {};
                SimProjCrit(eachCond).valueInhibitors = [];
                SimProjCrit(eachCond).typeCrit = typeCrit;
                SimProjCrit(eachCond).specChange = specChange;
                SimProjCrit(eachCond).numCritPass = numCritPass;
                SimProjCrit(eachCond).mathChange = mathChange;
                SimProjCrit(eachCond).signChange = signChange;
                SimProjCrit(eachCond).amountChange = amountChange;
                SimProjCrit(eachCond).EndPoint = EndPoint;
            end
        elseif any(regexpi(ScenType{1},'Inhib'))
            for eachCond = 1:size(ValuesCrit,1)
                SimProjCrit(eachCond).namesInhibitors = NamesCrit;
                SimProjCrit(eachCond).valueInhibitors = ValuesCrit;
                SimProjCrit(eachCond).namesStimuli = {};
                SimProjCrit(eachCond).valueStimuli = [];
                SimProjCrit(eachCond).typeCrit = typeCrit;
                SimProjCrit(eachCond).specChange = specChange;
                SimProjCrit(eachCond).numCritPass = numCritPass;
                SimProjCrit(eachCond).mathChange = mathChange;
                SimProjCrit(eachCond).signChange = signChange;
                SimProjCrit(eachCond).amountChange = amountChange;
                SimProjCrit(eachCond).EndPoint = EndPoint;
            end
        else
            error('could not identify if criteria condition was stim or inhib')
        end
    elseif any(regexpi(Criteria{6},'none'))
        typeCrit = 'NoFixScen';
        SimProjCrit(1).typeCrit = typeCrit;
        SimProjCrit(1).specChange = specChange;
        SimProjCrit(1).numCritPass = numCritPass;
        SimProjCrit(1).mathChange = mathChange;
        SimProjCrit(1).signChange = signChange;
        SimProjCrit(1).amountChange = amountChange;
        SimProjCrit(1).EndPoint = EndPoint;
    elseif any(regexpi(Criteria{6},'Model'))
        typeCrit = 'Model';
        startIx = regexpi(Criteria{6},':');
        ModelName = Criteria{6}(startIx+1:end);
        SimProjCrit = SimProject;
        for eachCond = 1:numel(SimProject);
            SimProjCrit(eachCond).typeCrit = typeCrit;
            SimProjCrit(eachCond).ModelName = ModelName;
            SimProjCrit(eachCond).specChange = specChange;
            SimProjCrit(eachCond).numCritPass = numCritPass;
            SimProjCrit(eachCond).mathChange = mathChange;
            SimProjCrit(eachCond).signChange = signChange;
            SimProjCrit(eachCond).amountChange = amountChange;
            SimProjCrit(eachCond).EndPoint = EndPoint;
        end
    else
        error('could not identify criteria condition')
    end
else
    disp(' ')
    disp('No Criteria Provided')
    SimProjCrit = 'No Criteria Provided';
end





