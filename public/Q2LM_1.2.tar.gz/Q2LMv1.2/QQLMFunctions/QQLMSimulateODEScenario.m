function AllResults = QQLMSimulateODEScenario(m,Scenario,Parameters)
% AllResults = QQLMSimulateODEScenario(m,Scenario,Parameters)
% Takes a previously imported SimProject or pointer to Scenario file and
% simulates previously imported model (m) or pointer to model file with
% ODE.  Because the simulator has to simulate each condition separately, it
% is much slower and this function is a tiny bit different than the cFL
% version.
%
% Parameters are also required (in the main QQLM Parameter structure, these
% are Parameters.Simulation).  Results are output into a 5-D array where
% the dimensions are as follows:
% Output dimension 1: Environments in Scenario
% Output dimension 2: Conditions in Scenario
% Output dimension 3: Species in Model (m)
% Output dimension 4: Time from simulation (maximum number of points stored
%       set by  Parameters.MaxTimeKept)
% Output dimension 5: Sinulated for each transfer function Parameter set 
%       in Model (m)
%
% � Copyright 2011,2012 Massachusetts Institute of Technology
%
% This file is part of Q2LM. Q2LM is free software: you can redistribute it
% and/or modify it under the terms of the GNU General Public License 
% version 2 as published by the Free Software Foundation. Q2LM is 
% distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
% PARTICULAR PURPOSE.  See the GNU General Public License at  
% http://www.gnu.org/licenses/old-licenses/gpl-2.0.html  for more details.
%
% By Melody K. Morris for Q2LM software.  5/4/11

% load model
if isstruct(m)
    Model = m;
elseif ischar(m)
    Model = QQLMLoadODEModelMultiParams(m);
else
    error('undefined model input type')
end

% import scenario if applicable
if isstruct(Scenario)
    SimProject = Scenario;
elseif ischar(Scenario)
    SimProject = ImportScenario(Scenario);
else
    error('undefined scenario input type')
end

if isfield(Parameters.SimEngSpecific,'tSpan')
    tSpan = Parameters.SimEngSpecific.tSpan;
else
    disp(' ')
    disp('No tSpan specified for ode solver. Using default of [0 25]')
    tSpan = [0 25];
end

if isfield(Parameters.SimEngSpecific,'DefInitCond')
    Def_IC = Parameters.SimEngSpecific.DefInitCond;
else
    disp(' ')
    disp('No DefInitCondition specified for ode solver. Using default of 1')
    Def_IC = 1;
end

% warn if something will be implicitly set by simulation
specWithNoIn =  find(~any(Model.interMat==1,2));
for eachSpec = 1:length(specWithNoIn)
    if ~any(strcmpi(cellstr(Model.specID(specWithNoIn(eachSpec),:)),SimProject(1).namesStimuli))
        disp(' ')
        disp(['Model species ' Model.specID(specWithNoIn(eachSpec),:) ' has no input and is not set in SimProject.',...
            ' It will always be zero in ODE simulation'])
    end
end

SimResultsTest = cell(numel(SimProject),size(Model.kMat,1));
allSizeCell = ones(numel(SimProject),size(Model.kMat,1));
count = 0;
countAll = 0;
timeODE = tic;
disp(' ') 
for eachScen = 1:numel(SimProject)
    currSimProject = SimProject(eachScen);
    currSimProject.namesSignals = cellstr(Model(1).specID);
    % pre-process inhibitors at this point
    currSimProject.valueInhibitors = 1-currSimProject.valueInhibitors;
    % set obsolete field defaults in case engine is old version
    currSimProject.timeCues = 0;
    currSimProject.timeSignals = [0; 1];
    currSimProject.valueSignals=zeros(size(currSimProject.valueStimuli,1),numel(currSimProject.namesSignals));
    % set indexStimuli to index between scenario and model species
    currSimProject.indexStimuli = nan(1,numel(currSimProject.namesStimuli));
    for i = 1:numel(currSimProject.namesStimuli)
        currSimProject.indexStimuli(i) = find(strcmpi(currSimProject.namesStimuli{i},cellstr(Model(1).specID)));
    end
    % set indexInhibitors to index between scenario and model species
    currSimProject.indexInhibitors = nan(1,numel(currSimProject.namesInhibitors));
    for i = 1:numel(currSimProject.namesInhibitors)
        currSimProject.indexInhibitors(i) = find(strcmpi(currSimProject.namesInhibitors{i},cellstr(Model(1).specID)));
    end
    % for each model
    for eachModel = 1:size(Model.kMat,1)
        % set parameters to go in model as those of current model
        g0 = Model.gMat(eachModel,:);
        n0 = Model.nMat(eachModel,:);
        k0 = Model.kMat(eachModel,:);
        SimResultsTest{eachScen,eachModel} = nan(max(size(currSimProject.valueStimuli,1),size(currSimProject.valueInhibitors,1)),size(Model.specID,1),Parameters.MaxTimeKept);
        % for each condition
        for eachCond = 1:max(size(currSimProject.valueStimuli,1),size(currSimProject.valueInhibitors,1))
            inh0 = ones(1,size(Model.specID,1));
            stim0 = ones(1,size(Model.specID,1));
            % to simulate inhibition, we multiply the activation part of the equations by the
            % amount uninhibited
            if ~isempty(currSimProject.valueInhibitors)
                inh0(currSimProject.indexInhibitors) = currSimProject.valueInhibitors(eachCond,:);
            end
            % to simulate stimulation, we make the derivative zero so it doesn't change and then
            % set the initial condition to stim value.
            if ~isempty(currSimProject.valueStimuli)
                IC = Def_IC*ones(1,size(Model.specID,1));
                IC(currSimProject.indexStimuli) = currSimProject.valueStimuli(eachCond,:);
                stim0(currSimProject.indexStimuli(currSimProject.valueStimuli(eachCond,:)>0)) = 0;
            else
                IC = Def_IC*ones(1,size(Model.specID,1));
                disp(' ')
                disp('Warning: ode simulation needs stimuli to set initial conditions');
            end
            % make anonymous function.
            if strcmpi(Parameters.ModelType,'ODE')
                inputFun = eval(['@(t,y)' blanks(1) Model.mFile(1:end-2) '(t,y,g0,n0,k0,inh0,stim0)']);
            elseif strcmpi(Parameters.ModelType,'ODESumProd')
                inputFun = eval(['@(t,y)' blanks(1) Model.mFileSumProd(1:end-2) '(t,y,g0,n0,k0,inh0,stim0)']);
            else
                error('Unrecognized ODE model type')
            end
            % simulate
            [t y]= Parameters.SimEngine(inputFun, tSpan, IC);
            currY = y';
            % only keep as much as you want or have memory for
            SimResultsTest{eachScen,eachModel}(eachCond,:,1:min(size(y,1),Parameters.MaxTimeKept))  = currY(:,end - (min(size(y,1),Parameters.MaxTimeKept)-1):end);
            allSizeCell(eachScen,eachModel) = min(size(y,1),Parameters.MaxTimeKept);
        count = count + 1;
        countAll = countAll + 1;
        if toc(timeODE) > 15
            disp(['On average, each of the last ' num2str(count) ' simulations took ' num2str(toc(timeODE)/count) ' seconds; ' num2str(countAll) ' simulations complete.'])
            timeODE = tic;
            count = 0;
        end
        end
    end
end
% restructure SimResultsTest into AllResults matrix
AllResults = nan(numel(SimProject),size(SimResultsTest{1,1},1),size(SimResultsTest{1,1},2),max(max(allSizeCell)),size(Model.kMat,1));
for eachScen = 1:numel(SimProject)
    for eachModel = 1:size(Model.kMat,1)
        AllResults(eachScen,:,:,1:allSizeCell(eachScen,eachModel),eachModel) = SimResultsTest{eachScen,eachModel}(:,:,1:allSizeCell(eachScen,eachModel));
    end
end