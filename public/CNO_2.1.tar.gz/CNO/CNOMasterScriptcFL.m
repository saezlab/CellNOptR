
%% 
%  This is an script to run a network optimization problem using CellNetOptimizer
%

CNOFolder=startCNO; %load CNO and (optionally) DataRail paths if not loaded
clc;

%% Choose the CNOProject with data & Model (Prior Knowledge Network) 
 
ModelName    = 'ToyPKNMMB'; % This is the toy model from the Manual (Morris et al. Methods Mol. Biol 2011, see documentation) 
%CNO is shipped also with (replace above ToyPKNMMB to use them)
% 'ExtToyPKNMMB'  - variant of the toy model ToyPKNMMB
% 'ToyPKNMSB'     - toy models used in Saez-Rodriguez et al. Mol syst. Biol 2009
% 'ToyPKNPCB      - toy model used in Morris et al. Plos CB 2011
% 'ExtLiverPKNPCB'- extended variant of LiverPKNPCB used in Morris et al. Plos CB 2011, which is a variant of the one in Saez-Rodriguez et al. MSB 2009
% 'LiverPKNDREAM' - subset of LiverPKNPCB used in the DREAM 4 Challenge 3: Predictive Signaling Network Modeling (www.the-dream-project.org)

FileWithData='ToyDataMMB'; %data to be used with ToyPKNMMB and ExtToyPKNMMB
%CNO is shipped also with the following data sets (replace above ToyDataMMB to use them) 
% 'ToyDataPCB'         - data for ToyPKNPCB          
% 'LiverDataPCB'       - data for LiverPKNPCB and ExtLiverPKNPCB. Can also be used with LiverPKNDREAM which is a smaller model
%                        (CellNOpt will automatically cut down the data to the one the model can analyze)   
% -- the MIDAS file with the data are also provided, these can be loaded with DataRail
%'ToyDataMMBMIDAS'     - corresponds to ToyDataMMB        
%'LiverDataDREAMMIDAS' - this is the raw data for LiverDataDREAM, and was posted in the DREAM website 



%% Below you can define  the parameters. see 'Manual'and/or 'Getting started' for information
%  The current values work well for the toy models. Increase parameters 
% MaxTime, PopulationSize, MaxGens, StallGenLimit and StallTimeLimit by a factor of 10-100 
%to run the Liver cases


% --------------------------------------------------------------------------
%  PARAMETERS FOR NETWORK IDENTIFICATION PROBLEM 
% ------------------------------------------------------------------------
Parameters=struct(...
   'ModelType', 'Fuzzy',...             % you can choose 'Boolean' or 'Fuzzy' 
... 
...% To identify the gates on the model
  'IdentGates',     'Nots',...             % Identify gates (default 'All'):
...                                       % 'All'  - all gates will be considered. This can create a large number of gates
...                                       % 'Nots' - only gates with negative inputs (nots) will be considered 
...                                       % 'None' - the gates will be left as they are
   'MaxInputsPerGate',2,...               % when the gates are expanded (IdentGates = 'All'), how many inputs 
...                                       % are maximally combined together. Default are 2
   'splitANDs',false,...                  % if you have ANDs in your prior knwoledge network and you want to keep them as such
...                                       % (because you are sure they are AND gates) set this to false; 
...                                       % if you want to allow them to become OR gates, set to true
...
...%Fuzzy-specific Parameters    
  'Type1Funs', [1 1.01 68.5098;...      % These transfer functions will be used in the
                1 3 0.2011;...          % discrete genetic algorithm.  Each row 
                1 3 0.3056;...          % is a transfer function with the 
                1 3 0.4187;...          % parameters ordered as
                1 3 0.5503;...          % [gain Hill_coefficient Sensitivity] 
                1 3 0.7245;...          % ([g n k])
                1 3 1.03],...
  'Type2Funs', [0.2 1 1;...             % By default Type 2 interactions are those connecting
                0.3 1 1;...             % the ligand inputs to downstream species.
                0.4 1 1;...             % Change the "Type2Def" Parameter to change.
                0.5 1 1;...
                0.6 1 1;...
                0.7 1 1;...
                0.8 1 1],...
   'ReductionThresh', [0 0.0001 0.0005 0.001 0.003 0.005],... %These are the reduction thresholds to use. 
...%To start the optimization from previous results    
  'StartPara',      [],...                % vector of parameters to start from
... 
...% parameters about objective function
  'nanfac',            1,...              % penalty factor for each simulation data point not calculable
  'sizefac',           0,...          % penalty factor for size (for each interaction in the graph underlaying the model)
...
...% to randomize models and/or data
  'RandomizeModel',    false,...          
  'RandType', 'SwapTails',...             % SwapTails, SwapInputs, SwapHeads, MinimalSpecifications, MinimalWithReadouts
  'RandomizeData',     false,...          %  
...  
...% define optimization method and stop criteria
      'Optimizer',      'CNOgadiscreteType', ...% Choose an optimization algorithm from the following:
      ...                                 % 'enumerate'        - enumerates all possible solutions
      ...                                 % 'CNOgabinary'      - optimizes binaryly  (0/1 for each hyperedge) with genetic algorithm 
      ...                                 % 'CNOga'            - uses a genetic algorithm and Sperner systems   
      ...                                 % 'none'             - will run preprocessing and then export preprocess model
      'MaxTime',        20,...             % maximal time (seconds) of optimization, at maxtime the optimization will stop
      'PopulationSize', 10,...            % size of population in genetic algorithm
      'MaxGens',        50,...            % maximal number of generations in genetic algorithm, if reached optimization stops   
      'StallGenLimit',  10,...            % maximal number of generations without changes in GA, if reached optimization stops
      'StallTimeLimit', 2*60,...          % maximal time without change in GA, if reached optimization will stop 
      'ObjLimit',   0.0,...               % if the objective func.(fitness value+size penalty) is reached the optimization stops
      'SelectivePressure',2.2,...
      'Pmutation',0.5,...                 % Probability that an individuum mutates; between 0 and 1
      'ShowStats','full',...              % 'simple', 'full' or 'none'
      'Statistics',true,...      
      'FitnessAssignment','rank',...      % the way that the fitness of an individuum is computed. 'proportional',{'rank'},
      'Ranking','nonlinear',...           % {'linear'}, 'nonlinear'. The latter allows for higher Selective Pressures
      'SigmaScaling',false,...            % if FitnessAssignment is 'proportional' you can do that to normalize the fitnesses
      'SigmaScalingCoeff',1.5,...         % larger coeff -> smaller variance in fitness of Population
      'Elitism',5,...                     % Number of best individua that go into the next Generation unchanged.
      'RelTol',0.1,...                    % relative tolerance for solutions; will define how many solutions are returned
      'Silent',false,...                  % to show or not the ga warnings
    ...
...% output options
  'SaveResults',    true,...              % save results( mat file in folder). Override to true if RunOnCluster or CreateReport
  'CreateReport',   false,...              % Creates a pdf report with summary of results. done automatically. if RunOnCluster   
   ...                                    % requires latex to create document and graphviz to plot maps  
  'ReportFolder',fullfile(CNOFolder,'Results'),...% folder where identification report will be saved
   'Log',           '');                  % a tag to append to the files and reports created);

%% ------------------------------------------------------------------------
% DO NOT EDIT THE FOLLOWING PART
% -------------------------------------------------------------------------

disp(' ******************************************************');
disp(' *');
disp(' *        STARTING NETWORK IDENTIFICATION PROBLEM     ');                                                                      
disp(' *');
disp(' ******************************************************');

%% Load Model and data
if exist('PGet')&&~isempty(PGet)
    disp(' ')
    disp([' Loading data from File ' FileWithData ', Array ' PGet.ArrayIndex])
    disp(' ')    
else
    PGet=[];
    disp(' ')
    disp([' Loading data from File ' FileWithData])
    disp(' ')      
end

[CNOProject    Parameters.SourceArray]    = CNOGetArrayFromFile(FileWithData,PGet);
if ~(isfield(Parameters,'SourceArray') &&isfield(Parameters.SourceArray,'Name'))
    Parameters.CNOProjectName = FileWithData;
      if strfind(Parameters.CNOProjectName,'.mat')
        Parameters.CNOProjectName=Parameters.CNOProjectName(1:end-4);
    end
end
disp([' and network (prior knowledge) ' ModelName])
% Load CNA or Cytoscape Model
Model = CNOLoadModel(ModelName);
Parameters.Model = Model;
Parameters.CurrentDirectory=pwd;

DRArray=CNORunIdentification(CNOProject,Parameters);
